<?php
/**
 * Product configuration model (stored as JSON in post meta `_moc_config`).
 *
 * Structure:
 * {
 *   "version": 1,
 *   "enabled": false,
 *   "views":  [ { "id": "front", "label": {"el": "Μπροστά"} } ],
 *   "base_layers": [ { "view": "front", "image": 123, "z": 0 } ],
 *   "dims":   [ { "id": "d1", "label": {"el": "180 x 90", "en": "...", "de": "..."}, "layers": [...] } ],
 *   "groups": [ {
 *       "id": "g1", "label": {...}, "type": "single"|"toggle", "required": true, "driver": true,
 *       "tiers":   [ { "id": "t1", "label": {...} } ],
 *       "options": [ { "id": "o1", "label": {...}, "tier": "t1", "swatch": 22977, "default": true,
 *                      "layers": [ { "view": "front", "image": 28724, "z": 1, "x": 0, "y": 0 } ] } ]
 *   } ]
 * }
 *
 * Pricing (see Pricing): driver groups select a row in the full-price matrix per dimension;
 * other groups add a surcharge per (dimension, tier). "toggle" groups are yes/no extras.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Config {

	const META      = '_moc_config';
	const LANGS     = array( 'el', 'en', 'de' );
	const ID_REGEX  = '/^[a-z0-9_-]{1,32}$/i';

	/** Always store/read config on the original-language product (WPML translations share it). */
	public static function source_id( $product_id ) {
		$product_id = (int) $product_id;
		if ( has_filter( 'wpml_object_id' ) ) {
			$default = apply_filters( 'wpml_default_language', null );
			$orig    = apply_filters( 'wpml_object_id', $product_id, 'product', true, $default );
			if ( $orig ) {
				return (int) $orig;
			}
		}
		return $product_id;
	}

	public static function get( $product_id ) {
		$raw = get_post_meta( self::source_id( $product_id ), self::META, true );
		if ( empty( $raw ) ) {
			return null;
		}
		$data = is_array( $raw ) ? $raw : json_decode( $raw, true );
		return is_array( $data ) ? self::normalize( $data ) : null;
	}

	public static function save( $product_id, array $config ) {
		$config = self::normalize( $config );
		update_post_meta( self::source_id( $product_id ), self::META, wp_slash( wp_json_encode( $config, JSON_UNESCAPED_UNICODE ) ) );
		return $config;
	}

	public static function is_enabled( $product_id ) {
		$c = self::get( $product_id );
		return $c && ! empty( $c['enabled'] ) && ! empty( $c['dims'] );
	}

	public static function empty_config() {
		return array(
			'version'     => 1,
			'enabled'     => false,
			'views'       => array( array( 'id' => 'front', 'label' => array( 'el' => 'Μπροστά', 'en' => 'Front', 'de' => 'Vorne' ) ) ),
			'base_layers' => array(),
			'dims'        => array(),
			'groups'      => array(),
		);
	}

	/** Sanitize and fill defaults. Unknown keys are dropped. */
	public static function normalize( array $c ) {
		$out            = self::empty_config();
		$out['enabled'] = ! empty( $c['enabled'] );

		if ( ! empty( $c['views'] ) && is_array( $c['views'] ) ) {
			$out['views'] = array();
			foreach ( $c['views'] as $v ) {
				$id = self::clean_id( $v['id'] ?? '' );
				if ( $id ) {
					$out['views'][] = array( 'id' => $id, 'label' => self::clean_label( $v['label'] ?? array() ) );
				}
			}
		}
		$out['base_layers'] = self::clean_layers( $c['base_layers'] ?? array() );

		$seen = array();
		foreach ( (array) ( $c['dims'] ?? array() ) as $d ) {
			$id = self::clean_id( $d['id'] ?? '' );
			if ( ! $id || isset( $seen[ $id ] ) ) {
				continue;
			}
			$seen[ $id ]     = true;
			$out['dims'][] = array(
				'id'     => $id,
				'label'  => self::clean_label( $d['label'] ?? array() ),
				'layers' => self::clean_layers( $d['layers'] ?? array() ),
			);
		}

		$gseen = array();
		foreach ( (array) ( $c['groups'] ?? array() ) as $g ) {
			$gid = self::clean_id( $g['id'] ?? '' );
			if ( ! $gid || isset( $gseen[ $gid ] ) ) {
				continue;
			}
			$gseen[ $gid ] = true;
			$type          = ( ( $g['type'] ?? '' ) === 'toggle' ) ? 'toggle' : 'single';
			$group         = array(
				'id'       => $gid,
				'label'    => self::clean_label( $g['label'] ?? array() ),
				'type'     => $type,
				'required' => 'single' === $type ? ! empty( $g['required'] ) : false,
				'driver'   => 'single' === $type ? ! empty( $g['driver'] ) : false,
				'tiers'    => array(),
				'options'  => array(),
			);
			$tseen         = array();
			foreach ( (array) ( $g['tiers'] ?? array() ) as $t ) {
				$tid = self::clean_id( $t['id'] ?? '' );
				if ( $tid && ! isset( $tseen[ $tid ] ) ) {
					$tseen[ $tid ]      = true;
					$group['tiers'][] = array( 'id' => $tid, 'label' => self::clean_label( $t['label'] ?? array() ) );
				}
			}
			$oseen       = array();
			$has_default = false;
			foreach ( (array) ( $g['options'] ?? array() ) as $o ) {
				$oid  = self::clean_id( $o['id'] ?? '' );
				$tier = self::clean_id( $o['tier'] ?? '' );
				if ( ! $oid || isset( $oseen[ $oid ] ) || ! isset( $tseen[ $tier ] ) ) {
					continue;
				}
				$oseen[ $oid ] = true;
				$def           = ! empty( $o['default'] ) && ! $has_default;
				$has_default   = $has_default || $def;
				$group['options'][] = array(
					'id'      => $oid,
					'label'   => self::clean_label( $o['label'] ?? array() ),
					'tier'    => $tier,
					'swatch'  => absint( $o['swatch'] ?? 0 ),
					'default' => $def,
					'layers'  => self::clean_layers( $o['layers'] ?? array() ),
				);
			}
			$out['groups'][] = $group;
		}
		return $out;
	}

	public static function clean_id( $id ) {
		$id = (string) $id;
		return preg_match( self::ID_REGEX, $id ) ? $id : '';
	}

	public static function clean_label( $label ) {
		$out = array();
		if ( is_string( $label ) ) {
			$label = array( 'el' => $label );
		}
		foreach ( self::LANGS as $l ) {
			$out[ $l ] = isset( $label[ $l ] ) ? sanitize_text_field( $label[ $l ] ) : '';
		}
		return $out;
	}

	public static function clean_layers( $layers ) {
		$out = array();
		foreach ( (array) $layers as $l ) {
			$img = absint( $l['image'] ?? 0 );
			if ( ! $img ) {
				continue;
			}
			$out[] = array(
				'view'  => self::clean_id( $l['view'] ?? 'front' ) ?: 'front',
				'image' => $img,
				'z'     => (int) ( $l['z'] ?? 0 ),
				'x'     => (float) ( $l['x'] ?? 0 ),
				'y'     => (float) ( $l['y'] ?? 0 ),
			);
		}
		return $out;
	}

	/** Label in the current language, falling back to Greek, then any non-empty value. */
	public static function label( $label, $lang = null ) {
		if ( is_string( $label ) ) {
			return $label;
		}
		$lang = $lang ?: self::current_lang();
		if ( ! empty( $label[ $lang ] ) ) {
			return $label[ $lang ];
		}
		if ( ! empty( $label['el'] ) ) {
			return $label['el'];
		}
		foreach ( (array) $label as $v ) {
			if ( '' !== $v ) {
				return $v;
			}
		}
		return '';
	}

	public static function current_lang() {
		$l = apply_filters( 'wpml_current_language', null );
		if ( $l && in_array( $l, self::LANGS, true ) ) {
			return $l;
		}
		$l = substr( determine_locale(), 0, 2 );
		return in_array( $l, self::LANGS, true ) ? $l : 'el';
	}

	public static function driver_groups( array $c ) {
		return array_values( array_filter( $c['groups'], static fn( $g ) => 'single' === $g['type'] && $g['driver'] ) );
	}

	public static function surcharge_groups( array $c ) {
		return array_values( array_filter( $c['groups'], static fn( $g ) => ! ( 'single' === $g['type'] && $g['driver'] ) ) );
	}

	/** Tier ids of a group that at least one option uses (only these need prices). */
	public static function used_tiers( array $g ) {
		$used = array();
		foreach ( $g['tiers'] as $t ) {
			foreach ( $g['options'] as $o ) {
				if ( $o['tier'] === $t['id'] ) {
					$used[] = $t['id'];
					break;
				}
			}
		}
		return $used;
	}

	public static function find_group( array $c, $gid ) {
		foreach ( $c['groups'] as $g ) {
			if ( $g['id'] === $gid ) {
				return $g;
			}
		}
		return null;
	}

	public static function find_option( array $g, $oid ) {
		foreach ( $g['options'] as $o ) {
			if ( $o['id'] === $oid ) {
				return $o;
			}
		}
		return null;
	}

	public static function find_tier( array $g, $tid ) {
		foreach ( $g['tiers'] as $t ) {
			if ( $t['id'] === $tid ) {
				return $t;
			}
		}
		return null;
	}

	public static function find_dim( array $c, $did ) {
		foreach ( $c['dims'] as $d ) {
			if ( $d['id'] === $did ) {
				return $d;
			}
		}
		return null;
	}

	/**
	 * Default selection: first dimension; per single group the default (or first) option;
	 * toggles off. Format: [ 'dim' => 'd1', 'options' => [ 'g1' => 'o1', 'g2' => null ] ].
	 */
	public static function default_selection( array $c ) {
		$sel = array(
			'dim'     => $c['dims'][0]['id'] ?? '',
			'options' => array(),
		);
		foreach ( $c['groups'] as $g ) {
			$pick = null;
			if ( 'single' === $g['type'] && $g['options'] ) {
				foreach ( $g['options'] as $o ) {
					if ( $o['default'] ) {
						$pick = $o['id'];
						break;
					}
				}
				if ( ! $pick && $g['required'] ) {
					$pick = $g['options'][0]['id'];
				}
			}
			$sel['options'][ $g['id'] ] = $pick;
		}
		return $sel;
	}

	/**
	 * Validate a submitted selection against the config. Returns a clean selection or WP_Error.
	 */
	public static function validate_selection( array $c, $raw ) {
		if ( ! is_array( $raw ) ) {
			return new \WP_Error( 'moc_bad_selection', __( 'Invalid configuration.', 'modoffice-configurator' ) );
		}
		$dim = self::clean_id( $raw['dim'] ?? '' );
		if ( ! self::find_dim( $c, $dim ) ) {
			return new \WP_Error( 'moc_bad_dim', __( 'Please choose a dimension.', 'modoffice-configurator' ) );
		}
		$sel = array( 'dim' => $dim, 'options' => array() );
		foreach ( $c['groups'] as $g ) {
			$oid = self::clean_id( $raw['options'][ $g['id'] ] ?? '' );
			if ( $oid && ! self::find_option( $g, $oid ) ) {
				return new \WP_Error( 'moc_bad_option', __( 'Invalid option selected.', 'modoffice-configurator' ) );
			}
			if ( ! $oid && 'single' === $g['type'] && $g['required'] ) {
				/* translators: %s: option group name, e.g. "Colour". */
				return new \WP_Error( 'moc_required', sprintf( __( 'Please choose: %s', 'modoffice-configurator' ), self::label( $g['label'] ) ) );
			}
			$sel['options'][ $g['id'] ] = $oid ?: null;
		}
		return $sel;
	}
}
