<?php
/**
 * Database tables and default options.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Install {

	public static function activate() {
		self::create_tables();
		add_option( 'moc_alert_email', 'sales@modoffice.gr' );
		add_option( 'moc_sync_wc_price', 'yes' );
		update_option( 'moc_db_version', MOC_DB_VERSION );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'moc_db_version' ) !== MOC_DB_VERSION ) {
			self::activate();
		}
	}

	/**
	 * Prices table: one row per (product, kind, dimension, key).
	 * kind = 'matrix'    key = "g1:t1|g2:t3"  (tiers of the price-driving groups) → full price
	 * kind = 'surcharge' key = "g3:t5"        (tier of a non-driving group)       → amount added
	 * History table keeps a JSON snapshot before every bulk change, for one-click restore.
	 */
	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}moc_prices (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				product_id bigint(20) unsigned NOT NULL,
				kind varchar(16) NOT NULL,
				dim_id varchar(32) NOT NULL,
				price_key varchar(191) NOT NULL,
				price decimal(12,2) NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY combo (product_id,kind,dim_id,price_key),
				KEY product_id (product_id)
			) $c;"
		);

		dbDelta(
			"CREATE TABLE {$wpdb->prefix}moc_price_history (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				created_at datetime NOT NULL,
				user_id bigint(20) unsigned NOT NULL DEFAULT 0,
				note varchar(255) NOT NULL DEFAULT '',
				snapshot longtext NOT NULL,
				PRIMARY KEY  (id)
			) $c;"
		);
	}
}
