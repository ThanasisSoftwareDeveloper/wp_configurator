<?php
/**
 * Cart & order integration. The price is always recomputed on the server from the stored
 * price table; the browser only sends the selection (dimension + chosen option ids).
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Cart {

	const KEY = 'moc';

	public static function init() {
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate' ), 10, 3 );
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'add_item_data' ), 10, 2 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'from_session' ), 10, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'set_prices' ), 20 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'item_data' ), 10, 2 );
		add_filter( 'woocommerce_cart_item_thumbnail', array( __CLASS__, 'thumbnail' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'order_item_meta' ), 10, 4 );
		add_filter( 'woocommerce_hidden_order_itemmeta', array( __CLASS__, 'hidden_meta' ) );
		add_filter( 'woocommerce_loop_add_to_cart_link', array( __CLASS__, 'loop_button' ), 10, 2 );
		add_filter( 'woocommerce_product_add_to_cart_url', array( __CLASS__, 'loop_url' ), 10, 2 );
		add_action( 'woocommerce_after_order_itemmeta', array( __CLASS__, 'admin_order_preview' ), 10, 2 );
	}

	/** Read and validate the posted selection for a product. Returns [config, selection, result] or WP_Error. */
	public static function posted_selection( $product_id ) {
		$c = Config::get( $product_id );
		if ( ! $c ) {
			return new \WP_Error( 'moc_no_config', __( 'This product cannot be configured.', 'modoffice-configurator' ) );
		}
		$raw = isset( $_POST['moc_selection'] ) ? json_decode( wp_unslash( $_POST['moc_selection'] ), true ) : null; // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput -- WooCommerce add-to-cart form; validated against the config below.
		$sel = Config::validate_selection( $c, $raw ?: Config::default_selection( $c ) );
		if ( is_wp_error( $sel ) ) {
			return $sel;
		}
		$r = Pricing::compute( $c, $sel, Price_Store::get( $product_id ) );
		return array( $c, $sel, $r );
	}

	public static function validate( $passed, $product_id, $qty ) {
		if ( ! Config::is_enabled( $product_id ) ) {
			return $passed;
		}
		$res = self::posted_selection( $product_id );
		if ( is_wp_error( $res ) ) {
			wc_add_notice( $res->get_error_message(), 'error' );
			return false;
		}
		if ( null === $res[2]['total'] ) {
			Alerts::customer_hit( $product_id, $res[2]['missing'] );
			wc_add_notice( __( 'The price of this combination is being updated. Please choose another combination or contact us.', 'modoffice-configurator' ), 'error' );
			return false;
		}
		return $passed;
	}

	public static function add_item_data( $data, $product_id ) {
		if ( ! Config::is_enabled( $product_id ) ) {
			return $data;
		}
		$res = self::posted_selection( $product_id );
		if ( is_wp_error( $res ) ) {
			return $data;
		}
		$data[ self::KEY ] = array(
			'selection' => $res[1],
			'price'     => $res[2]['total'],
			'hash'      => md5( wp_json_encode( $res[1] ) ), // Different configurations = separate cart lines.
		);
		return $data;
	}

	public static function from_session( $item, $values ) {
		if ( isset( $values[ self::KEY ] ) ) {
			$item[ self::KEY ] = $values[ self::KEY ];
		}
		return $item;
	}

	/** Recompute every configured line from the current price table. */
	public static function set_prices( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		foreach ( $cart->get_cart() as $key => $item ) {
			if ( empty( $item[ self::KEY ]['selection'] ) ) {
				continue;
			}
			$pid = $item['product_id'];
			$c   = Config::get( $pid );
			$sel = $c ? Config::validate_selection( $c, $item[ self::KEY ]['selection'] ) : null;
			$r   = ( $c && ! is_wp_error( $sel ) ) ? Pricing::compute( $c, $sel, Price_Store::get( $pid ) ) : null;
			if ( ! $r || null === $r['total'] ) {
				// Configuration no longer valid or no longer priced: remove it rather than sell at a wrong price.
				$cart->remove_cart_item( $key );
				if ( $r ) {
					Alerts::customer_hit( $pid, $r['missing'] );
				}
				wc_add_notice( __( 'A configured product was removed from your cart because its options or price changed. Please configure it again.', 'modoffice-configurator' ), 'notice' );
				continue;
			}
			$item['data']->set_price( $r['total'] );
			$cart->cart_contents[ $key ][ self::KEY ]['price'] = $r['total'];
		}
	}

	/** Lines shown under the product name: "Dimensions: 200 x 90", "Main colour: White (Premium)", … */
	public static function describe( $product_id, array $sel, $lang = null ) {
		$c = Config::get( $product_id );
		if ( ! $c ) {
			return array();
		}
		$out = array();
		$dim = Config::find_dim( $c, $sel['dim'] );
		if ( $dim ) {
			$out[] = array( __( 'Dimensions', 'modoffice-configurator' ), Config::label( $dim['label'], $lang ) );
		}
		foreach ( $c['groups'] as $g ) {
			$oid = $sel['options'][ $g['id'] ] ?? null;
			$o   = $oid ? Config::find_option( $g, $oid ) : null;
			if ( ! $o ) {
				continue;
			}
			if ( 'toggle' === $g['type'] ) {
				$out[] = array( Config::label( $g['label'], $lang ), __( 'Yes', 'modoffice-configurator' ) );
				continue;
			}
			$t     = Config::find_tier( $g, $o['tier'] );
			$value = Config::label( $o['label'], $lang );
			if ( $t && count( $g['tiers'] ) > 1 ) {
				$value .= ' (' . Config::label( $t['label'], $lang ) . ')';
			}
			$out[] = array( Config::label( $g['label'], $lang ), $value );
		}
		return $out;
	}

	public static function item_data( $data, $item ) {
		if ( empty( $item[ self::KEY ]['selection'] ) ) {
			return $data;
		}
		foreach ( self::describe( $item['product_id'], $item[ self::KEY ]['selection'] ) as $line ) {
			$data[] = array( 'key' => $line[0], 'value' => $line[1] );
		}
		return $data;
	}

	/** Image layers (attachment ids, bottom to top) for a selection. */
	public static function layer_ids( $product_id, array $sel ) {
		$c = Config::get( $product_id );
		if ( ! $c ) {
			return array();
		}
		$layers = $c['base_layers'];
		$dim    = Config::find_dim( $c, $sel['dim'] );
		if ( $dim ) {
			$layers = array_merge( $layers, $dim['layers'] );
		}
		foreach ( $c['groups'] as $g ) {
			$oid = $sel['options'][ $g['id'] ] ?? null;
			$o   = $oid ? Config::find_option( $g, $oid ) : null;
			if ( $o ) {
				$layers = array_merge( $layers, $o['layers'] );
			}
		}
		$layers = array_values( array_filter( $layers, static fn( $l ) => 'front' === $l['view'] ) );
		usort( $layers, static fn( $a, $b ) => $a['z'] <=> $b['z'] );
		return array_map( static fn( $l ) => $l['image'], $layers );
	}

	public static function layered_html( array $ids, $size = 'woocommerce_thumbnail' ) {
		if ( ! $ids ) {
			return '';
		}
		$html = '<span class="moc-thumb" style="position:relative;display:inline-block;line-height:0">';
		foreach ( $ids as $i => $id ) {
			$src   = wp_get_attachment_image_url( $id, $size );
			$style = 0 === $i ? 'display:block;max-width:100%;height:auto' : 'position:absolute;left:0;top:0;width:100%;height:auto';
			if ( $src ) {
				$html .= '<img src="' . esc_url( $src ) . '" alt="" style="' . esc_attr( $style ) . '" />';
			}
		}
		return $html . '</span>';
	}

	public static function thumbnail( $html, $item ) {
		if ( empty( $item[ self::KEY ]['selection'] ) ) {
			return $html;
		}
		$layered = self::layered_html( self::layer_ids( $item['product_id'], $item[ self::KEY ]['selection'] ) );
		return $layered ?: $html;
	}

	public static function order_item_meta( $order_item, $cart_key, $values, $order ) {
		if ( empty( $values[ self::KEY ]['selection'] ) ) {
			return;
		}
		$sel = $values[ self::KEY ]['selection'];
		foreach ( self::describe( $values['product_id'], $sel ) as $line ) {
			$order_item->add_meta_data( $line[0], $line[1] );
		}
		$order_item->add_meta_data( '_moc_selection', wp_json_encode( $sel ) );
		$order_item->add_meta_data( '_moc_layers', wp_json_encode( self::layer_ids( $values['product_id'], $sel ) ) );
		$order_item->add_meta_data( '_moc_price', $values[ self::KEY ]['price'] );
	}

	public static function hidden_meta( $keys ) {
		return array_merge( $keys, array( '_moc_selection', '_moc_layers', '_moc_price' ) );
	}

	/** In the admin order screen, show the configured composition under the line item. */
	public static function admin_order_preview( $item_id, $item ) {
		if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
			return;
		}
		$ids = json_decode( (string) $item->get_meta( '_moc_layers' ), true );
		if ( $ids ) {
			echo '<div style="max-width:160px;margin-top:6px">' . self::layered_html( array_map( 'absint', $ids ), 'thumbnail' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts.
		}
	}

	/** In shop lists, a configurable product links to its page ("Choose options") instead of adding directly. */
	public static function loop_button( $html, $product ) {
		if ( Config::is_enabled( $product->get_id() ) ) {
			return sprintf( '<a href="%s" class="button product_type_simple">%s</a>', esc_url( $product->get_permalink() ), esc_html__( 'Configure', 'modoffice-configurator' ) );
		}
		return $html;
	}

	public static function loop_url( $url, $product ) {
		return Config::is_enabled( $product->get_id() ) ? $product->get_permalink() : $url;
	}
}
