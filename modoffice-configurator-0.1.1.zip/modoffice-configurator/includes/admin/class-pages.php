<?php
/**
 * Admin pages under WooCommerce → Configurator: prices (CSV), missing prices, history, settings.
 *
 * @package ModofficeConfigurator
 */

namespace MOC\Admin;

use MOC\Alerts;
use MOC\Config;
use MOC\Csv;
use MOC\Price_Store;
use MOC\Pricing;

defined( 'ABSPATH' ) || exit;

class Pages {

	const CAP = 'manage_woocommerce';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_post_moc_export', array( __CLASS__, 'handle_export' ) );
		add_action( 'admin_post_moc_import', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_moc_import_apply', array( __CLASS__, 'handle_import_apply' ) );
		add_action( 'admin_post_moc_restore', array( __CLASS__, 'handle_restore' ) );
		add_action( 'admin_post_moc_settings', array( __CLASS__, 'handle_settings' ) );
		add_action( 'admin_post_moc_recheck', array( __CLASS__, 'handle_recheck' ) );
		add_action( 'admin_post_moc_migrate', array( __CLASS__, 'handle_migrate' ) );
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', __( 'Configurator prices', 'modoffice-configurator' ), __( 'Configurator', 'modoffice-configurator' ), self::CAP, 'moc-prices', array( __CLASS__, 'page_prices' ) );
		add_submenu_page( 'woocommerce', __( 'Missing prices', 'modoffice-configurator' ), __( 'Missing prices', 'modoffice-configurator' ), self::CAP, 'moc-missing', array( __CLASS__, 'page_missing' ) );
		add_submenu_page( 'woocommerce', __( 'Migrate from WP Configurator', 'modoffice-configurator' ), __( 'Configurator migration', 'modoffice-configurator' ), self::CAP, 'moc-migrate', array( __CLASS__, 'page_migrate' ) );
	}

	private static function tabs( $active ) {
		$tabs = array(
			'moc-prices'  => __( 'Prices (Excel/CSV)', 'modoffice-configurator' ),
			'moc-missing' => __( 'Missing prices', 'modoffice-configurator' ),
			'moc-migrate' => __( 'Migration', 'modoffice-configurator' ),
		);
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $slug => $label ) {
			printf( '<a class="nav-tab %s" href="%s">%s</a>', $slug === $active ? 'nav-tab-active' : '', esc_url( admin_url( 'admin.php?page=' . $slug ) ), esc_html( $label ) );
		}
		echo '</nav>';
	}

	private static function notice() {
		$msg = get_transient( 'moc_notice_' . get_current_user_id() );
		if ( $msg ) {
			delete_transient( 'moc_notice_' . get_current_user_id() );
			printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $msg[0] ), wp_kses_post( $msg[1] ) );
		}
	}

	private static function flash( $type, $text, $page ) {
		set_transient( 'moc_notice_' . get_current_user_id(), array( $type, $text ), 120 );
		wp_safe_redirect( admin_url( 'admin.php?page=' . $page ) );
		exit;
	}

	private static function guard( $action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Not allowed.', 'modoffice-configurator' ) );
		}
		check_admin_referer( $action );
	}

	/* ---------- Prices: export / import / history / settings ---------- */

	public static function page_prices() {
		$products = Csv::configured_products();
		$pending  = get_transient( 'moc_import_' . get_current_user_id() );
		echo '<div class="wrap"><h1>' . esc_html__( 'Configurator prices', 'modoffice-configurator' ) . '</h1>';
		self::tabs( 'moc-prices' );
		self::notice();

		if ( $pending ) {
			self::render_preview( $pending );
		}

		// Export.
		echo '<h2>1. ' . esc_html__( 'Export', 'modoffice-configurator' ) . '</h2>';
		echo '<p>' . esc_html__( 'Download the prices to edit them in Excel. Missing prices are exported with an empty price cell.', 'modoffice-configurator' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'moc_export' );
		echo '<input type="hidden" name="action" value="moc_export" />';
		echo '<select name="product_ids[]" multiple size="8" style="min-width:420px">';
		foreach ( $products as $pid ) {
			printf( '<option value="%d" selected>%s (#%d)</option>', (int) $pid, esc_html( get_the_title( $pid ) ), (int) $pid );
		}
		echo '</select><p>';
		submit_button( __( 'Download CSV', 'modoffice-configurator' ), 'secondary', 'submit', false );
		echo '</p></form>';

		// Import.
		echo '<h2>2. ' . esc_html__( 'Import', 'modoffice-configurator' ) . '</h2>';
		echo '<p>' . esc_html__( 'Upload the edited file. Nothing is saved until you confirm the preview. Empty price cells leave the price unchanged.', 'modoffice-configurator' ) . '</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'moc_import' );
		echo '<input type="hidden" name="action" value="moc_import" />';
		echo '<input type="file" name="csv" accept=".csv,text/csv" required /> ';
		submit_button( __( 'Preview changes', 'modoffice-configurator' ), 'primary', 'submit', false );
		echo '</form>';

		// History.
		echo '<h2>3. ' . esc_html__( 'History (restore)', 'modoffice-configurator' ) . '</h2>';
		echo '<p>' . esc_html__( 'Before every change the previous prices are saved here.', 'modoffice-configurator' ) . '</p>';
		$hist = Price_Store::history( 20 );
		if ( ! $hist ) {
			echo '<p><em>' . esc_html__( 'No history yet.', 'modoffice-configurator' ) . '</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>#</th><th>' . esc_html__( 'Date', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'User', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'Note', 'modoffice-configurator' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $hist as $h ) {
				$u = get_userdata( (int) $h['user_id'] );
				echo '<tr><td>' . (int) $h['id'] . '</td><td>' . esc_html( get_date_from_gmt( $h['created_at'], 'd/m/Y H:i' ) ) . '</td><td>' . esc_html( $u ? $u->display_name : '-' ) . '</td><td>' . esc_html( $h['note'] ) . '</td><td>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'' . esc_js( __( 'Restore these prices? The current prices are saved to history first.', 'modoffice-configurator' ) ) . '\')">';
				wp_nonce_field( 'moc_restore' );
				echo '<input type="hidden" name="action" value="moc_restore" /><input type="hidden" name="history_id" value="' . (int) $h['id'] . '" />';
				submit_button( __( 'Restore', 'modoffice-configurator' ), 'small', 'submit', false );
				echo '</form></td></tr>';
			}
			echo '</tbody></table>';
		}

		// Settings.
		echo '<h2>4. ' . esc_html__( 'Settings', 'modoffice-configurator' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'moc_settings' );
		echo '<input type="hidden" name="action" value="moc_settings" />';
		echo '<table class="form-table"><tr><th>' . esc_html__( 'E-mail for missing prices', 'modoffice-configurator' ) . '</th><td><input type="email" class="regular-text" name="alert_email" value="' . esc_attr( get_option( 'moc_alert_email', 'sales@modoffice.gr' ) ) . '" /></td></tr>';
		echo '<tr><th>' . esc_html__( 'WooCommerce price', 'modoffice-configurator' ) . '</th><td><label><input type="checkbox" name="sync_wc_price" value="yes" ' . checked( 'yes', get_option( 'moc_sync_wc_price', 'yes' ), false ) . ' /> ' . esc_html__( 'Set the product price to the price of the default configuration (shown in shop lists and feeds).', 'modoffice-configurator' ) . '</label></td></tr></table>';
		submit_button( __( 'Save settings', 'modoffice-configurator' ) );
		echo '</form></div>';
	}

	private static function render_preview( array $pending ) {
		$changes = $pending['changes'];
		echo '<div class="notice notice-info" style="padding:10px 14px"><h2 style="margin-top:4px">' . esc_html__( 'Preview: changes to be saved', 'modoffice-configurator' ) . '</h2>';
		/* translators: 1: changed prices, 2: unchanged prices, 3: file name. */
		echo '<p>' . esc_html( sprintf( __( '%1$d prices change, %2$d stay the same (file: %3$s).', 'modoffice-configurator' ), count( $changes ), (int) $pending['unchanged'], $pending['file'] ) ) . '</p>';
		if ( $pending['errors'] ) {
			echo '<div class="notice notice-warning inline"><p><strong>' . esc_html__( 'Lines skipped:', 'modoffice-configurator' ) . '</strong></p><ul style="list-style:disc;margin-left:20px">';
			foreach ( array_slice( $pending['errors'], 0, 50 ) as $e ) {
				echo '<li>' . esc_html( $e ) . '</li>';
			}
			echo '</ul></div>';
		}
		if ( $changes ) {
			echo '<div style="max-height:420px;overflow:auto"><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Product', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'Dimension', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'Combination', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'Old', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'New', 'modoffice-configurator' ) . '</th></tr></thead><tbody>';
			$configs = array();
			foreach ( $changes as $ch ) {
				list( $pid, $kind, $dim, $key, $old, $new ) = $ch;
				$c = $configs[ $pid ] ??= Config::get( $pid );
				echo '<tr><td>' . esc_html( get_the_title( $pid ) ) . '</td><td>' . esc_html( Pricing::dim_label( $c, $dim ) ) . '</td><td>' . esc_html( Pricing::key_label( $c, $key ) ) . ( 'surcharge' === $kind ? ' <em>(+)</em>' : '' ) . '</td><td>' . ( null === $old ? '<span style="color:#d63638">—</span>' : esc_html( wc_format_localized_price( $old ) ) ) . '</td><td><strong>' . esc_html( wc_format_localized_price( $new ) ) . '</strong></td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:10px 0">';
		wp_nonce_field( 'moc_import_apply' );
		echo '<input type="hidden" name="action" value="moc_import_apply" />';
		if ( $changes ) {
			submit_button( __( 'Save these prices', 'modoffice-configurator' ), 'primary', 'apply', false );
			echo ' ';
		}
		submit_button( __( 'Cancel', 'modoffice-configurator' ), 'secondary', 'cancel', false );
		echo '</form></div>';
	}

	public static function handle_export() {
		self::guard( 'moc_export' );
		$ids = array_map( 'absint', (array) ( $_POST['product_ids'] ?? array() ) );
		$ids = array_values( array_intersect( $ids, Csv::configured_products() ) );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="configurator-prices-' . gmdate( 'Y-m-d' ) . '.csv"' );
		echo Csv::export( $ids ); // phpcs:ignore WordPress.Security.EscapeOutput -- CSV download.
		exit;
	}

	public static function handle_import() {
		self::guard( 'moc_import' );
		if ( empty( $_FILES['csv']['tmp_name'] ) || ! is_uploaded_file( $_FILES['csv']['tmp_name'] ) ) {
			self::flash( 'error', __( 'No file uploaded.', 'modoffice-configurator' ), 'moc-prices' );
		}
		$res = Csv::parse( $_FILES['csv']['tmp_name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( is_wp_error( $res ) ) {
			self::flash( 'error', $res->get_error_message(), 'moc-prices' );
		}
		$res['file'] = sanitize_file_name( wp_unslash( $_FILES['csv']['name'] ?? 'file.csv' ) );
		set_transient( 'moc_import_' . get_current_user_id(), $res, HOUR_IN_SECONDS );
		wp_safe_redirect( admin_url( 'admin.php?page=moc-prices' ) );
		exit;
	}

	public static function handle_import_apply() {
		self::guard( 'moc_import_apply' );
		$key     = 'moc_import_' . get_current_user_id();
		$pending = get_transient( $key );
		delete_transient( $key );
		if ( isset( $_POST['cancel'] ) || ! $pending ) {
			self::flash( 'info', __( 'Import cancelled. Nothing was changed.', 'modoffice-configurator' ), 'moc-prices' );
		}
		/* translators: %s: file name. */
		$hid = Csv::apply( $pending['changes'], sprintf( __( 'CSV import: %s', 'modoffice-configurator' ), $pending['file'] ) );
		/* translators: 1: number of prices, 2: snapshot number. */
		self::flash( 'success', sprintf( __( '%1$d prices saved. Previous prices kept in history #%2$d.', 'modoffice-configurator' ), count( $pending['changes'] ), $hid ), 'moc-prices' );
	}

	public static function handle_restore() {
		self::guard( 'moc_restore' );
		$r = Price_Store::restore( absint( $_POST['history_id'] ?? 0 ) );
		if ( is_wp_error( $r ) ) {
			self::flash( 'error', $r->get_error_message(), 'moc-prices' );
		}
		/* translators: %d: number of products. */
		self::flash( 'success', sprintf( __( 'Prices restored for %d products.', 'modoffice-configurator' ), $r ), 'moc-prices' );
	}

	public static function handle_settings() {
		self::guard( 'moc_settings' );
		$email = sanitize_email( wp_unslash( $_POST['alert_email'] ?? '' ) );
		if ( $email && is_email( $email ) ) {
			update_option( 'moc_alert_email', $email );
		}
		update_option( 'moc_sync_wc_price', isset( $_POST['sync_wc_price'] ) ? 'yes' : 'no' );
		self::flash( 'success', __( 'Settings saved.', 'modoffice-configurator' ), 'moc-prices' );
	}

	/* ---------- Missing prices ---------- */

	public static function page_missing() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Missing prices', 'modoffice-configurator' ) . '</h1>';
		self::tabs( 'moc-missing' );
		self::notice();
		echo '<p>' . esc_html__( 'Every combination of an enabled product must have a price. Combinations listed here cannot be bought until they are priced.', 'modoffice-configurator' ) . '</p>';
		/* translators: %s: e-mail address. */
		echo '<p>' . esc_html( sprintf( __( 'Alerts are e-mailed to %s.', 'modoffice-configurator' ), Alerts::email() ) ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'moc_recheck' );
		echo '<input type="hidden" name="action" value="moc_recheck" />';
		submit_button( __( 'Check all products now', 'modoffice-configurator' ), 'secondary', 'submit', false );
		echo '</form>';

		$any = false;
		foreach ( Csv::configured_products() as $pid ) {
			$c = Config::get( $pid );
			if ( ! $c ) {
				continue;
			}
			$missing = Pricing::missing( $c, Price_Store::get( $pid ) );
			if ( ! $missing ) {
				continue;
			}
			$any = true;
			printf(
				'<h2>%s <small>(%s, %d)</small> <a class="button button-small" href="%s">%s</a></h2>',
				esc_html( get_the_title( $pid ) ),
				$c['enabled'] ? esc_html__( 'enabled', 'modoffice-configurator' ) : esc_html__( 'not enabled yet', 'modoffice-configurator' ),
				count( $missing ),
				esc_url( admin_url( 'post.php?post=' . $pid . '&action=edit' ) ),
				esc_html__( 'Edit prices', 'modoffice-configurator' )
			);
			echo '<ul style="list-style:disc;margin-left:24px">';
			foreach ( array_slice( $missing, 0, 100 ) as $m ) {
				echo '<li>' . esc_html( Pricing::dim_label( $c, $m[1] ) . ' — ' . Pricing::key_label( $c, $m[2] ) ) . ( 'surcharge' === $m[0] ? ' <em>(+)</em>' : '' ) . '</li>';
			}
			echo '</ul>';
		}
		if ( ! $any ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'All combinations have a price.', 'modoffice-configurator' ) . '</p></div>';
		}
		echo '</div>';
	}

	/* ---------- Migration from WP Configurator Pro ---------- */

	public static function page_migrate() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Migrate from WP Configurator Pro', 'modoffice-configurator' ) . '</h1>';
		self::tabs( 'moc-migrate' );
		self::notice();
		echo '<p>' . esc_html__( 'Copies the structure (dimensions, groups, tiers, options) and the same Media Library images of each product\'s WP Configurator. WP Configurator is not changed. Migrated products stay disabled until you enable them on the product page; prices are imported separately.', 'modoffice-configurator' ) . '</p>';

		$report = get_transient( 'moc_migrate_report_' . get_current_user_id() );
		if ( $report ) {
			delete_transient( 'moc_migrate_report_' . get_current_user_id() );
			echo '<table class="widefat striped" style="max-width:1000px;margin-bottom:16px"><thead><tr><th>' . esc_html__( 'Product', 'modoffice-configurator' ) . '</th><th>' . esc_html__( 'Result', 'modoffice-configurator' ) . '</th></tr></thead><tbody>';
			foreach ( $report as $pid => $r ) {
				$color = 'migrated' === $r['status'] ? '#1e4620' : ( 'error' === $r['status'] ? '#8a2424' : '#646970' );
				echo '<tr><td>' . esc_html( get_the_title( $pid ) ) . '</td><td style="color:' . esc_attr( $color ) . '">' . esc_html( $r['message'] );
				foreach ( $r['warnings'] as $w ) {
					echo '<br><em>' . esc_html( $w ) . '</em>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}

		$linked = \MOC\Migrator::linked_products();
		if ( ! $linked ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'No products are linked to WP Configurator Pro.', 'modoffice-configurator' ) . '</p></div></div>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'moc_migrate' );
		echo '<input type="hidden" name="action" value="moc_migrate" />';
		echo '<table class="widefat striped" style="max-width:1000px"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.moc-mig\').forEach(c=>c.checked=this.checked)" /></td><th>' . esc_html__( 'Product', 'modoffice-configurator' ) . '</th><th>SKU</th><th>' . esc_html__( 'Modoffice configurator', 'modoffice-configurator' ) . '</th></tr></thead><tbody>';
		foreach ( $linked as $pid => $cfg ) {
			$c       = Config::get( $pid );
			$product = wc_get_product( $pid );
			$state   = ! $c ? '—' : ( $c['enabled'] ? __( 'enabled', 'modoffice-configurator' ) : __( 'migrated, not enabled', 'modoffice-configurator' ) );
			printf(
				'<tr><th class="check-column"><input class="moc-mig" type="checkbox" name="product_ids[]" value="%d" %s /></th><td><a href="%s">%s</a></td><td>%s</td><td>%s</td></tr>',
				(int) $pid,
				$c ? '' : 'checked',
				esc_url( admin_url( 'post.php?post=' . $pid . '&action=edit#moc_configurator' ) ),
				esc_html( get_the_title( $pid ) ),
				esc_html( $product ? $product->get_sku() : '' ),
				esc_html( $state )
			);
		}
		echo '</tbody></table>';
		echo '<p><label><input type="checkbox" name="overwrite" value="1" /> ' . esc_html__( 'Overwrite products that already have a Modoffice configuration (their structure is rebuilt; prices for unchanged ids are kept; enabled/disabled is kept).', 'modoffice-configurator' ) . '</label></p>';
		submit_button( __( 'Migrate selected products', 'modoffice-configurator' ) );
		echo '</form></div>';
	}

	public static function handle_migrate() {
		self::guard( 'moc_migrate' );
		$ids    = array_map( 'absint', (array) ( $_POST['product_ids'] ?? array() ) );
		$ids    = array_values( array_intersect( $ids, array_keys( \MOC\Migrator::linked_products() ) ) );
		$report = array();
		foreach ( $ids as $pid ) {
			$report[ $pid ] = \MOC\Migrator::migrate( $pid, ! empty( $_POST['overwrite'] ) );
		}
		set_transient( 'moc_migrate_report_' . get_current_user_id(), $report, 10 * MINUTE_IN_SECONDS );
		$n = count( array_filter( $report, static fn( $r ) => 'migrated' === $r['status'] ) );
		/* translators: 1: migrated, 2: selected. */
		self::flash( 'success', sprintf( __( '%1$d of %2$d products migrated.', 'modoffice-configurator' ), $n, count( $ids ) ), 'moc-migrate' );
	}

	public static function handle_recheck() {
		self::guard( 'moc_recheck' );
		$n = 0;
		foreach ( Csv::configured_products() as $pid ) {
			$n += count( Alerts::check_product( $pid ) );
		}
		/* translators: %d: number of missing prices. */
		self::flash( $n ? 'warning' : 'success', sprintf( __( 'Check finished: %d missing prices in enabled products.', 'modoffice-configurator' ), $n ), 'moc-missing' );
	}
}
