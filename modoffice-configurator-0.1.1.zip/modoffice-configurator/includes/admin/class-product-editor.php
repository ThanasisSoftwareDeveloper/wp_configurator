<?php
/**
 * "Configurator" tab in the WooCommerce product data box: structure editor + price tables.
 * The UI is rendered by assets/admin/editor.js from the JSON below and posted back as JSON.
 *
 * @package ModofficeConfigurator
 */

namespace MOC\Admin;

use MOC\Config;
use MOC\Price_Store;
use MOC\Pricing;

defined( 'ABSPATH' ) || exit;

class Product_Editor {

	public static function init() {
		add_action( 'add_meta_boxes_product', array( __CLASS__, 'meta_box' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save' ), 20 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function meta_box() {
		add_meta_box( 'moc_configurator', __( 'Configurator (Modoffice)', 'modoffice-configurator' ), array( __CLASS__, 'panel' ), 'product', 'normal', 'high' );
	}

	public static function assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || 'product' !== $screen->post_type || ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'moc-admin', MOC_URL . 'assets/admin/editor.css', array(), MOC_VERSION . '.' . filemtime( MOC_DIR . 'assets/admin/editor.css' ) );
		wp_enqueue_script( 'moc-admin', MOC_URL . 'assets/admin/editor.js', array( 'jquery' ), MOC_VERSION . '.' . filemtime( MOC_DIR . 'assets/admin/editor.js' ), true );
		wp_localize_script( 'moc-admin', 'mocI18n', self::js_strings() );
	}

	public static function panel( $post ) {
		$pid    = Config::source_id( $post->ID );
		$is_tr  = (int) $pid !== (int) $post->ID;
		$config = Config::get( $pid ) ?: Config::empty_config();
		$prices = Price_Store::get( $pid );

		$images = array();
		foreach ( self::collect_images( $config ) as $id ) {
			$src = wp_get_attachment_image_url( $id, 'thumbnail' );
			if ( $src ) {
				$images[ $id ] = $src;
			}
		}
		?>
		<div id="moc_product_data">
			<?php if ( $is_tr ) : ?>
				<p class="moc-note"><?php esc_html_e( 'This is a translation. The configurator and prices are edited on the original (Greek) product; only the labels are translated there too.', 'modoffice-configurator' ); ?></p>
			<?php else : ?>
				<?php wp_nonce_field( 'moc_save', 'moc_nonce' ); ?>
				<input type="hidden" name="moc_config_json" id="moc_config_json" value="" />
				<input type="hidden" name="moc_prices_json" id="moc_prices_json" value="" />
				<div id="moc-editor"
					data-config="<?php echo esc_attr( wp_json_encode( $config, JSON_UNESCAPED_UNICODE ) ); ?>"
					data-prices="<?php echo esc_attr( wp_json_encode( $prices ) ); ?>"
					data-images="<?php echo esc_attr( wp_json_encode( $images ) ); ?>"></div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function collect_images( array $c ) {
		$ids = array();
		foreach ( $c['base_layers'] as $l ) {
			$ids[] = $l['image'];
		}
		foreach ( $c['dims'] as $d ) {
			foreach ( $d['layers'] as $l ) {
				$ids[] = $l['image'];
			}
		}
		foreach ( $c['groups'] as $g ) {
			foreach ( $g['options'] as $o ) {
				$ids[] = $o['swatch'];
				foreach ( $o['layers'] as $l ) {
					$ids[] = $l['image'];
				}
			}
		}
		return array_unique( array_filter( $ids ) );
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['moc_nonce'], $_POST['moc_config_json'] )
			|| ! wp_verify_nonce( sanitize_key( $_POST['moc_nonce'] ), 'moc_save' )
			|| ! current_user_can( 'edit_product', $post_id ) ) {
			return;
		}
		$raw_config = json_decode( wp_unslash( $_POST['moc_config_json'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized by Config::normalize.
		if ( ! is_array( $raw_config ) ) {
			return; // Editor did not load (e.g. JS error): keep what is stored.
		}
		$pid    = Config::source_id( $post_id );
		$config = Config::save( $pid, $raw_config );

		$raw_prices = json_decode( wp_unslash( $_POST['moc_prices_json'] ?? '' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- parsed per value below.
		if ( is_array( $raw_prices ) ) {
			$new = self::filter_prices( $config, $raw_prices );
			$old = Price_Store::get( $pid );
			if ( self::canonical( $new ) !== self::canonical( $old ) ) {
				/* translators: %s: product name. */
				Price_Store::snapshot( array( $pid ), sprintf( __( 'Edit prices: %s', 'modoffice-configurator' ), get_the_title( $pid ) ) );
				Price_Store::replace( $pid, $new );
			}
		}
		do_action( 'moc_config_saved', $pid );
	}

	/** Keep only prices that the current structure can use (drops prices of deleted tiers/dimensions). */
	private static function filter_prices( array $c, array $raw ) {
		$out = array( 'matrix' => array(), 'surcharge' => array() );
		foreach ( Pricing::required( $c ) as $r ) {
			list( $kind, $dim, $key ) = $r;
			if ( isset( $raw[ $kind ][ $dim ][ $key ] ) ) {
				$p = Price_Store::parse_price( $raw[ $kind ][ $dim ][ $key ] );
				if ( null !== $p ) {
					$out[ $kind ][ $dim ][ $key ] = $p;
				}
			}
		}
		return $out;
	}

	private static function canonical( array $p ) {
		$flat = array();
		foreach ( array( 'matrix', 'surcharge' ) as $k ) {
			foreach ( (array) ( $p[ $k ] ?? array() ) as $d => $keys ) {
				foreach ( (array) $keys as $key => $v ) {
					$flat[ "$k|$d|$key" ] = round( (float) $v, 2 );
				}
			}
		}
		ksort( $flat );
		return $flat;
	}

	private static function js_strings() {
		return array(
			'enabled'        => __( 'Use this configurator on the shop', 'modoffice-configurator' ),
			'enabledHelp'    => __( 'While off, the product page is not changed.', 'modoffice-configurator' ),
			'dims'           => __( 'Dimensions', 'modoffice-configurator' ),
			'addDim'         => __( 'Add dimension', 'modoffice-configurator' ),
			'groups'         => __( 'Option groups', 'modoffice-configurator' ),
			'addGroup'       => __( 'Add option group', 'modoffice-configurator' ),
			'groupType'      => __( 'Type', 'modoffice-configurator' ),
			'single'         => __( 'One choice (colours, front…)', 'modoffice-configurator' ),
			'toggle'         => __( 'Extra yes/no', 'modoffice-configurator' ),
			'required'       => __( 'Required', 'modoffice-configurator' ),
			'driver'         => __( 'Full-price table (like the PDF)', 'modoffice-configurator' ),
			'driverHelp'     => __( 'On: you enter the final price per dimension and tier combination. Off: you enter the amount added per dimension and tier.', 'modoffice-configurator' ),
			'tiers'          => __( 'Price tiers', 'modoffice-configurator' ),
			'addTier'        => __( 'Add tier', 'modoffice-configurator' ),
			'options'        => __( 'Options', 'modoffice-configurator' ),
			'addOption'      => __( 'Add option', 'modoffice-configurator' ),
			'tier'           => __( 'Tier', 'modoffice-configurator' ),
			'default'        => __( 'Default', 'modoffice-configurator' ),
			'swatch'         => __( 'Swatch', 'modoffice-configurator' ),
			'layer'          => __( 'Layer image', 'modoffice-configurator' ),
			'layerZ'         => __( 'Layer order', 'modoffice-configurator' ),
			'baseLayers'     => __( 'Base image (always shown)', 'modoffice-configurator' ),
			'choose'         => __( 'Choose', 'modoffice-configurator' ),
			'remove'         => __( 'Remove', 'modoffice-configurator' ),
			'confirmRemove'  => __( 'Remove this? Its prices will be deleted when you update the product.', 'modoffice-configurator' ),
			'prices'         => __( 'Prices (incl. VAT, per unit)', 'modoffice-configurator' ),
			'fullPrice'      => __( 'Final price', 'modoffice-configurator' ),
			'surcharge'      => __( 'Amount added', 'modoffice-configurator' ),
			'noDims'         => __( 'Add at least one dimension to enter prices.', 'modoffice-configurator' ),
			'missing'        => __( 'missing prices', 'modoffice-configurator' ),
			'allPriced'      => __( 'All combinations have a price.', 'modoffice-configurator' ),
			'fillRow'        => __( 'Fill row', 'modoffice-configurator' ),
			'fillRowPrompt'  => __( 'Price for every dimension in this row:', 'modoffice-configurator' ),
			'none'           => __( 'none', 'modoffice-configurator' ),
			'base'           => __( 'Price', 'modoffice-configurator' ),
			'labelEl'        => 'EL',
			'labelEn'        => 'EN',
			'labelDe'        => 'DE',
			'chooseImage'    => __( 'Choose image', 'modoffice-configurator' ),
			'useImage'       => __( 'Use this image', 'modoffice-configurator' ),
			'moveUp'         => __( 'Move up', 'modoffice-configurator' ),
			'moveDown'       => __( 'Move down', 'modoffice-configurator' ),
			'newDim'         => __( 'New dimension', 'modoffice-configurator' ),
			'newGroup'       => __( 'New group', 'modoffice-configurator' ),
			'newTier'        => __( 'New tier', 'modoffice-configurator' ),
			'newOption'      => __( 'New option', 'modoffice-configurator' ),
		);
	}
}
