<?php
/**
 * Missing-price detection and e-mail alerts to the shop administrator.
 *
 * Goal: no combination is ever left without a price. Whenever prices or the configuration of an
 * enabled product change, the product is re-checked; if prices are missing, an e-mail lists them
 * (once per distinct set of missing prices). If a customer reaches an unpriced combination on the
 * shop, an alert is sent too (at most once per combination per day).
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Alerts {

	const OPTION = 'moc_missing_index'; // [ product_id => count ] for enabled products.

	public static function init() {
		add_action( 'moc_prices_changed', array( __CLASS__, 'check_product' ), 20 );
		add_action( 'moc_config_saved', array( __CLASS__, 'check_product' ), 20 );
		add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
	}

	public static function email() {
		$e = get_option( 'moc_alert_email', 'sales@modoffice.gr' );
		return is_email( $e ) ? $e : get_option( 'admin_email' );
	}

	/** Re-check one product, update the index and e-mail if its set of missing prices changed. */
	public static function check_product( $product_id ) {
		$product_id = Config::source_id( $product_id );
		$c          = Config::get( $product_id );
		$index      = (array) get_option( self::OPTION, array() );

		if ( ! $c || empty( $c['enabled'] ) ) {
			unset( $index[ $product_id ] );
			update_option( self::OPTION, $index, false );
			return array();
		}

		$missing = Pricing::missing( $c, Price_Store::get( $product_id ) );
		if ( $missing ) {
			$index[ $product_id ] = count( $missing );
		} else {
			unset( $index[ $product_id ] );
		}
		update_option( self::OPTION, $index, false );

		$hash = $missing ? md5( wp_json_encode( $missing ) ) : '';
		if ( $missing && get_post_meta( $product_id, '_moc_alerted_hash', true ) !== $hash ) {
			self::send( $product_id, $c, $missing, 'admin' );
			update_post_meta( $product_id, '_moc_alerted_hash', $hash );
		} elseif ( ! $missing ) {
			delete_post_meta( $product_id, '_moc_alerted_hash' );
		}
		return $missing;
	}

	/** Called when a customer selects an unpriced combination on the shop. */
	public static function customer_hit( $product_id, array $missing ) {
		$product_id = Config::source_id( $product_id );
		$c          = Config::get( $product_id );
		if ( ! $c || ! $missing ) {
			return;
		}
		$tkey = 'moc_hit_' . md5( $product_id . wp_json_encode( $missing ) );
		if ( get_transient( $tkey ) ) {
			return;
		}
		set_transient( $tkey, 1, DAY_IN_SECONDS );
		self::send( $product_id, $c, $missing, 'customer' );
	}

	private static function send( $product_id, array $c, array $missing, $source ) {
		$title = get_the_title( $product_id );
		$link  = admin_url( 'post.php?post=' . $product_id . '&action=edit#moc_configurator' );
		$lines = array();
		foreach ( $missing as $m ) {
			$lines[] = '- ' . Pricing::dim_label( $c, $m[1] ) . ' | ' . Pricing::key_label( $c, $m[2] ) . ( 'surcharge' === $m[0] ? ' (' . __( 'surcharge', 'modoffice-configurator' ) . ')' : '' );
		}
		$intro = 'customer' === $source
			? __( 'A customer selected a combination that has no price, so it could not be added to the cart.', 'modoffice-configurator' )
			: __( 'The following combinations have no price yet. Customers cannot buy them until they are priced.', 'modoffice-configurator' );

		/* translators: %s: product name. */
		$subject = sprintf( __( '[Modoffice e-shop] Missing prices: %s', 'modoffice-configurator' ), $title );
		$body    = $intro . "\n\n" . $title . ' (#' . $product_id . ")\n\n" . implode( "\n", array_slice( $lines, 0, 200 ) );
		if ( count( $lines ) > 200 ) {
			/* translators: %d: number of further missing prices. */
			$body .= "\n" . sprintf( __( '…and %d more', 'modoffice-configurator' ), count( $lines ) - 200 );
		}
		$body .= "\n\n" . __( 'Set the prices here:', 'modoffice-configurator' ) . "\n" . $link . "\n";
		wp_mail( self::email(), $subject, $body );
	}

	public static function admin_notice() {
		if ( ! current_user_can( 'edit_products' ) ) {
			return;
		}
		$index = array_filter( (array) get_option( self::OPTION, array() ) );
		if ( ! $index ) {
			return;
		}
		$url = admin_url( 'admin.php?page=moc-missing' );
		printf(
			'<div class="notice notice-warning"><p><strong>Modoffice Configurator:</strong> %s <a href="%s">%s</a></p></div>',
			/* translators: 1: number of missing prices, 2: number of products. */
			esc_html( sprintf( __( '%1$d prices are missing in %2$d products.', 'modoffice-configurator' ), array_sum( $index ), count( $index ) ) ),
			esc_url( $url ),
			esc_html__( 'Show missing prices', 'modoffice-configurator' )
		);
	}
}
