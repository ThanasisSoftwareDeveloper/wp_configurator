<?php
/**
 * CSV export/import of prices (Excel-friendly: UTF-8 with BOM, semicolon separated).
 *
 * Columns: product_id;sku;product;kind;dim_id;dimension;price_key;combination;price
 * The id columns identify the price; the label columns are for people. On import only
 * product_id, kind, dim_id, price_key and price are read. An empty price leaves the stored
 * price unchanged.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Csv {

	const HEADER = array( 'product_id', 'sku', 'product', 'kind', 'dim_id', 'dimension', 'price_key', 'combination', 'price' );

	/** Product ids that have a configurator (original language only). */
	public static function configured_products() {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s", Config::META ) );
		$out = array();
		foreach ( $ids as $id ) {
			if ( 'product' === get_post_type( $id ) && (int) Config::source_id( $id ) === (int) $id ) {
				$out[] = (int) $id;
			}
		}
		sort( $out );
		return $out;
	}

	public static function rows_for_product( $pid ) {
		$c = Config::get( $pid );
		if ( ! $c ) {
			return array();
		}
		$prices  = Price_Store::get( $pid );
		$product = wc_get_product( $pid );
		$rows    = array();
		foreach ( Pricing::required( $c ) as $r ) {
			list( $kind, $dim, $key ) = $r;
			$v      = $prices[ $kind ][ $dim ][ $key ] ?? null;
			$rows[] = array(
				$pid,
				$product ? $product->get_sku() : '',
				get_the_title( $pid ),
				$kind,
				$dim,
				Pricing::dim_label( $c, $dim ),
				$key,
				Pricing::key_label( $c, $key ),
				null === $v ? '' : number_format( (float) $v, 2, ',', '' ),
			);
		}
		return $rows;
	}

	public static function export( array $product_ids ) {
		$fh = fopen( 'php://temp', 'w+' );
		fwrite( $fh, "\xEF\xBB\xBF" );
		fputcsv( $fh, self::HEADER, ';' );
		foreach ( $product_ids as $pid ) {
			foreach ( self::rows_for_product( $pid ) as $row ) {
				fputcsv( $fh, $row, ';' );
			}
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return $csv;
	}

	/**
	 * Parse an uploaded CSV and compare it with the stored prices.
	 *
	 * @return array|\WP_Error [ 'changes' => [ [pid, kind, dim, key, old, new] ], 'errors' => [ string ], 'unchanged' => int ]
	 */
	public static function parse( $path ) {
		$raw = file_get_contents( $path );
		if ( false === $raw || '' === $raw ) {
			return new \WP_Error( 'moc_csv_empty', __( 'The file is empty.', 'modoffice-configurator' ) );
		}
		$raw = preg_replace( '/^\xEF\xBB\xBF/', '', $raw );
		if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			$raw = mb_convert_encoding( $raw, 'UTF-8', 'Windows-1253' ); // Greek Excel default.
		}
		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		$first = '';
		while ( $lines && '' === trim( $first ) ) {
			$first = array_shift( $lines );
		}
		if ( 0 === stripos( trim( $first ), 'sep=' ) ) {
			$first = array_shift( $lines );
		}
		$delim  = substr_count( $first, ';' ) >= substr_count( $first, ',' ) ? ';' : ',';
		$header = array_map( static fn( $h ) => strtolower( trim( $h ) ), str_getcsv( $first, $delim ) );
		$col    = array_flip( $header );
		foreach ( array( 'product_id', 'kind', 'dim_id', 'price_key', 'price' ) as $need ) {
			if ( ! isset( $col[ $need ] ) ) {
				/* translators: %s: column name. */
				return new \WP_Error( 'moc_csv_header', sprintf( __( 'Column "%s" is missing. Export a file first and edit that one.', 'modoffice-configurator' ), $need ) );
			}
		}

		$changes   = array();
		$errors    = array();
		$unchanged = 0;
		$configs   = array();
		$required  = array();
		foreach ( $lines as $n => $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$f    = str_getcsv( $line, $delim );
			$row  = $n + 2;
			$pid  = (int) ( $f[ $col['product_id'] ] ?? 0 );
			$kind = trim( $f[ $col['kind'] ] ?? '' );
			$dim  = trim( $f[ $col['dim_id'] ] ?? '' );
			$key  = trim( $f[ $col['price_key'] ] ?? '' );
			$pstr = trim( $f[ $col['price'] ] ?? '' );
			if ( '' === $pstr ) {
				continue;
			}
			if ( ! isset( $configs[ $pid ] ) ) {
				$configs[ $pid ] = Config::get( $pid );
				$required[ $pid ] = array();
				if ( $configs[ $pid ] ) {
					foreach ( Pricing::required( $configs[ $pid ] ) as $r ) {
						$required[ $pid ][ implode( "\t", $r ) ] = true;
					}
				}
			}
			if ( ! $configs[ $pid ] ) {
				/* translators: 1: line number, 2: product id. */
				$errors[] = sprintf( __( 'Line %1$d: product #%2$d has no configurator.', 'modoffice-configurator' ), $row, $pid );
				continue;
			}
			if ( ! isset( $required[ $pid ][ "$kind\t$dim\t$key" ] ) ) {
				/* translators: %d: line number. */
				$errors[] = sprintf( __( 'Line %d: this combination does not exist in the product (was it renamed or deleted?).', 'modoffice-configurator' ), $row );
				continue;
			}
			$new = Price_Store::parse_price( $pstr );
			if ( null === $new ) {
				/* translators: 1: line number, 2: the value found. */
				$errors[] = sprintf( __( 'Line %1$d: "%2$s" is not a price.', 'modoffice-configurator' ), $row, $pstr );
				continue;
			}
			$old = Price_Store::get( $pid )[ $kind ][ $dim ][ $key ] ?? null;
			if ( null !== $old && abs( $old - $new ) < 0.005 ) {
				$unchanged++;
				continue;
			}
			$changes[] = array( $pid, $kind, $dim, $key, $old, $new );
		}
		return array( 'changes' => $changes, 'errors' => $errors, 'unchanged' => $unchanged );
	}

	/** Apply parsed changes (snapshot first). */
	public static function apply( array $changes, $note ) {
		$pids = array_unique( array_map( static fn( $c ) => (int) $c[0], $changes ) );
		$hid  = Price_Store::snapshot( $pids, $note );
		foreach ( $changes as $c ) {
			Price_Store::set( $c[0], $c[1], $c[2], $c[3], $c[5] );
		}
		foreach ( $pids as $pid ) {
			do_action( 'moc_prices_changed', $pid );
		}
		return $hid;
	}
}
