<?php
/**
 * Converts WP Configurator Pro configurations to Modoffice Configurator.
 *
 * - Reads the layer tree of the configurator linked to a product (product meta `_wpc_config_id`).
 * - Re-uses the same Media Library attachments (no image is copied or deleted).
 * - Top-level group named like "Διαστάσεις" → dimensions; other groups → option groups;
 *   their sub-groups (Basic / Premium / Γυαλί …) → price tiers; images → options.
 * - Ids are derived from WP Configurator uids, so running it again produces the same ids and
 *   prices imported for them keep working.
 * - The new configuration is saved DISABLED. Prices are not migrated (they come from the new
 *   price lists).
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Migrator {

	const DIM_REGEX    = '/δι[αά]στ[αά]σ|dimension|abmessung|μ[εέ]γεθ|size/iu';
	const LAYER_KEYS   = array( '_wpc_components', 'wpc_components', '_wpc_layers', 'wpc_layers', 'components', 'layers' );
	const SOURCE_META  = '_moc_migrated_from';

	/** Products that are linked to a WP Configurator configuration: [ product_id => config_id ]. */
	public static function linked_products() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value <> ''", '_wpc_config_id' ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $r ) {
			if ( 'product' === get_post_type( $r['post_id'] ) && (int) Config::source_id( $r['post_id'] ) === (int) $r['post_id'] ) {
				$out[ (int) $r['post_id'] ] = (int) $r['meta_value'];
			}
		}
		ksort( $out );
		return $out;
	}

	/** Find the layer tree of a WP Configurator configuration post. */
	public static function load_layers( $config_id ) {
		foreach ( self::LAYER_KEYS as $k ) {
			$layers = self::as_layers( get_post_meta( $config_id, $k, true ) );
			if ( $layers ) {
				return $layers;
			}
		}
		// Fallback: any meta value or the post content that looks like a layer tree.
		foreach ( (array) get_post_meta( $config_id ) as $values ) {
			foreach ( (array) $values as $v ) {
				$layers = self::as_layers( $v );
				if ( $layers ) {
					return $layers;
				}
			}
		}
		$post = get_post( $config_id );
		return $post ? self::as_layers( $post->post_content ) : array();
	}

	private static function as_layers( $v ) {
		if ( is_string( $v ) ) {
			$v = maybe_unserialize( $v );
		}
		if ( is_string( $v ) ) {
			$j = json_decode( $v, true );
			$v = is_array( $j ) ? $j : null;
		}
		if ( is_array( $v ) && isset( $v['layers'] ) && is_array( $v['layers'] ) ) {
			$v = $v['layers'];
		}
		if ( ! is_array( $v ) || ! $v || array_keys( $v ) !== range( 0, count( $v ) - 1 ) ) {
			return array();
		}
		foreach ( $v as $node ) {
			if ( ! is_array( $node ) || ! isset( $node['uid'], $node['type'] ) ) {
				return array();
			}
		}
		return $v;
	}

	/** Convert a WP Configurator layer tree to a Modoffice config (array, not saved). */
	public static function convert( array $layers ) {
		$c         = Config::empty_config();
		$ids       = array();
		$warn      = array();
		$dims_done = false;

		foreach ( $layers as $node ) {
			$name     = trim( (string) ( $node['name'] ?? '' ) );
			$children = (array) ( $node['children'] ?? array() );

			// Plain top-level image → always-visible base layer.
			if ( ! $children && 'image' === ( $node['type'] ?? '' ) ) {
				$l = self::layer_of( $node );
				if ( $l ) {
					$c['base_layers'][] = $l;
				}
				continue;
			}
			if ( ! $children ) {
				continue;
			}

			$is_dim_group = preg_match( self::DIM_REGEX, $name ) && ! self::has_subgroups( $node );

			if ( $is_dim_group && $dims_done ) {
				// A second size group (e.g. "Διαστάσεις Βοηθητικού"): an option group where every size has its own price tier.
				$group = array(
					'id'       => self::unique_id( 'g', $node['uid'] ?? $name, $ids ),
					'label'    => array( 'el' => $name, 'en' => '', 'de' => '' ),
					'type'     => 'single',
					'required' => ! empty( $node['settings']['required'] ),
					'driver'   => true,
					'tiers'    => array(),
					'options'  => array(),
				);
				foreach ( self::flatten_images( $children ) as $img ) {
					$label            = trim( (string) ( $img['settings']['label'] ?? $img['name'] ?? '' ) );
					$tid              = self::unique_id( 't', ( $img['uid'] ?? $label ) . '-t', $ids );
					$group['tiers'][] = array( 'id' => $tid, 'label' => array( 'el' => $label, 'en' => '', 'de' => '' ) );
					$opt              = self::option_of( $img, $tid, $ids );
					$opt['layers']    = array(); // Size labels use a placeholder image in WP Configurator.
					$group['options'][] = $opt;
				}
				if ( $group['options'] ) {
					$c['groups'][] = $group;
				}
				continue;
			}

			if ( $is_dim_group ) {
				$dims_done = true;
				$img_ids = array_unique( array_filter( array_map( static fn( $ch ) => (int) ( $ch['settings']['views']['front']['image'] ?? 0 ), $children ) ) );
				$shared  = count( $children ) > 1 && count( $img_ids ) <= 1; // Same placeholder image on every size → not a real layer.
				foreach ( $children as $ch ) {
					$label = trim( (string) ( $ch['settings']['label'] ?? $ch['name'] ?? '' ) );
					$l     = $shared ? null : self::layer_of( $ch );
					$c['dims'][] = array(
						'id'     => self::unique_id( 'd', $ch['uid'] ?? $label, $ids ),
						'label'  => array( 'el' => $label, 'en' => '', 'de' => '' ),
						'layers' => $l ? array( $l ) : array(),
					);
				}
				continue;
			}

			$group = array(
				'id'       => self::unique_id( 'g', $node['uid'] ?? $name, $ids ),
				'label'    => array( 'el' => $name, 'en' => '', 'de' => '' ),
				'type'     => 'single',
				'required' => ! empty( $node['settings']['required'] ),
				'driver'   => false,
				'tiers'    => array(),
				'options'  => array(),
			);

			$direct = array();
			$blocks = array(); // [ tier seed, tier label, images ].
			foreach ( $children as $ch ) {
				if ( ! empty( $ch['children'] ) ) {
					$blocks[] = array( $ch['uid'] ?? $ch['name'], trim( (string) ( $ch['name'] ?? '' ) ), self::flatten_images( $ch['children'] ) );
				} elseif ( 'image' === ( $ch['type'] ?? '' ) ) {
					$direct[] = $ch;
				}
			}
			if ( $direct ) {
				array_unshift( $blocks, array( ( $node['uid'] ?? $name ) . '-std', 'Basic', $direct ) );
			}
			foreach ( $blocks as $b ) {
				self::add_tiers( $group, $b[0], $b[1], $b[2], $ids );
			}
			if ( ! $group['options'] ) {
				/* translators: %s: group name. */
				$warn[] = sprintf( __( 'Group "%s" has no options and was skipped.', 'modoffice-configurator' ), $name );
				continue;
			}

			// A single optional choice (e.g. "Κρυφός φωτισμός: Ναι") is a yes/no extra (amount added).
			// Every other group takes part in the full-price table, so the price lists' combination
			// columns (Basic / Premium / two-colour, desk × side unit …) can be entered as printed.
			if ( 1 === count( $group['options'] ) && ! $group['required'] ) {
				$group['type'] = 'toggle';
			} else {
				$group['driver'] = true;
			}
			$c['groups'][] = $group;
		}

		if ( ! $c['dims'] ) {
			$c['dims'][] = array( 'id' => 'std', 'label' => array( 'el' => 'Standard', 'en' => '', 'de' => '' ), 'layers' => array() );
			$warn[]      = __( 'No dimensions group found: a single "Standard" dimension was created.', 'modoffice-configurator' );
		}
		$c['enabled'] = false;
		return array( 'config' => Config::normalize( $c ), 'warnings' => $warn );
	}

	/**
	 * Add one or more tiers for a WP Configurator sub-group. Options that had a different WP
	 * Configurator surcharge than the rest of the sub-group (e.g. "Άλλο RAL", or white/black frame
	 * +27) get their own tier, so they can be priced separately: "Γυαλί", "Γυαλί (Άλλο Ral)".
	 */
	private static function add_tiers( array &$group, $seed, $label, array $images, array &$ids ) {
		$by_price = array();
		foreach ( $images as $img ) {
			$p                      = (string) (float) str_replace( array( '+', ',' ), array( '', '.' ), (string) ( $img['settings']['price'] ?? '0' ) );
			$by_price[ $p ][]       = $img;
		}
		// The most common price keeps the plain tier name; the others are named after their options.
		uasort( $by_price, static fn( $a, $b ) => count( $b ) <=> count( $a ) );
		$first = true;
		foreach ( $by_price as $imgs ) {
			if ( $first ) {
				$tid   = self::unique_id( 't', $seed, $ids );
				$tname = $label;
				$first = false;
			} else {
				$names = array_map( static fn( $i ) => trim( (string) ( $i['settings']['label'] ?? $i['name'] ?? '' ) ), $imgs );
				$tid   = self::unique_id( 't', $seed . '-' . ( $imgs[0]['uid'] ?? count( $group['tiers'] ) ), $ids );
				$tname = $label . ' (' . implode( ', ', array_slice( $names, 0, 3 ) ) . ( count( $names ) > 3 ? '…' : '' ) . ')';
			}
			$group['tiers'][] = array( 'id' => $tid, 'label' => array( 'el' => $tname, 'en' => '', 'de' => '' ) );
			foreach ( $imgs as $img ) {
				$group['options'][] = self::option_of( $img, $tid, $ids );
			}
		}
	}

	private static function has_subgroups( array $node ) {
		foreach ( (array) ( $node['children'] ?? array() ) as $ch ) {
			if ( ! empty( $ch['children'] ) ) {
				return true;
			}
		}
		return false;
	}

	private static function flatten_images( array $nodes ) {
		$out = array();
		foreach ( $nodes as $n ) {
			if ( ! empty( $n['children'] ) ) {
				$out = array_merge( $out, self::flatten_images( $n['children'] ) );
			} elseif ( 'image' === ( $n['type'] ?? '' ) ) {
				$out[] = $n;
			}
		}
		return $out;
	}

	private static function option_of( array $img, $tier, array &$ids ) {
		$l = self::layer_of( $img );
		return array(
			'id'      => self::unique_id( 'o', $img['uid'] ?? $img['name'], $ids ),
			'label'   => array( 'el' => trim( (string) ( $img['settings']['label'] ?? $img['name'] ?? '' ) ), 'en' => '', 'de' => '' ),
			'tier'    => $tier,
			'swatch'  => (int) ( $img['settings']['icon'] ?? 0 ),
			'default' => ! empty( $img['settings']['active'] ),
			'layers'  => $l ? array( $l ) : array(),
		);
	}

	private static function layer_of( array $node ) {
		$f   = $node['settings']['views']['front'] ?? array();
		$img = (int) ( $f['image'] ?? 0 );
		if ( ! $img ) {
			return null;
		}
		return array( 'view' => 'front', 'image' => $img, 'z' => (int) ( $f['z_index'] ?? 0 ), 'x' => 0, 'y' => 0 );
	}

	/** Stable, valid, unique id derived from a WP Configurator uid (e.g. "WRUU-3dq0" → "wruu-3dq0"). */
	private static function unique_id( $prefix, $seed, array &$ids ) {
		$id = strtolower( preg_replace( '/[^a-z0-9_-]+/i', '-', (string) $seed ) );
		$id = trim( $id, '-' );
		if ( '' === $id || ! preg_match( '/^[a-z]/', $id ) ) {
			$id = $prefix . '-' . $id;
		}
		$id   = substr( $id, 0, 28 );
		$base = $id;
		$n    = 2;
		while ( isset( $ids[ $id ] ) ) {
			$id = substr( $base, 0, 25 ) . '-' . $n++;
		}
		$ids[ $id ] = true;
		return $id;
	}

	/**
	 * Migrate one product. Existing Modoffice configurations are kept unless $overwrite.
	 *
	 * @return array [ status: migrated|skipped|error, message, warnings ]
	 */
	public static function migrate( $product_id, $overwrite = false ) {
		$product_id = (int) $product_id;
		$cfg_id     = (int) get_post_meta( $product_id, '_wpc_config_id', true );
		if ( ! $cfg_id || ! get_post( $cfg_id ) ) {
			return array( 'status' => 'error', 'message' => __( 'No WP Configurator configuration linked.', 'modoffice-configurator' ), 'warnings' => array() );
		}
		if ( Config::get( $product_id ) && ! $overwrite ) {
			return array( 'status' => 'skipped', 'message' => __( 'Already has a Modoffice configuration (not overwritten).', 'modoffice-configurator' ), 'warnings' => array() );
		}
		$layers = self::load_layers( $cfg_id );
		if ( ! $layers ) {
			return array( 'status' => 'error', 'message' => __( 'Could not read the WP Configurator layers.', 'modoffice-configurator' ), 'warnings' => array() );
		}
		$res = self::convert( $layers );
		if ( $overwrite && ( $old = Config::get( $product_id ) ) ) {
			$res['config']['enabled'] = ! empty( $old['enabled'] ); // Re-running never switches a product on or off.
		}
		Config::save( $product_id, $res['config'] );
		update_post_meta( $product_id, self::SOURCE_META, $cfg_id );
		do_action( 'moc_config_saved', $product_id );

		$n_opts = array_sum( array_map( static fn( $g ) => count( $g['options'] ), $res['config']['groups'] ) );
		return array(
			'status'   => 'migrated',
			/* translators: 1: dimensions, 2: groups, 3: options. */
			'message'  => sprintf( __( '%1$d dimensions, %2$d option groups, %3$d options.', 'modoffice-configurator' ), count( $res['config']['dims'] ), count( $res['config']['groups'] ), $n_opts ),
			'warnings' => $res['warnings'],
		);
	}
}
