<?php
/**
 * Plugin bootstrap: wires the modules together.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	private static $instance;

	public static function instance() {
		return self::$instance ?: ( self::$instance = new self() );
	}

	private function __construct() {
		Install::maybe_upgrade();
		Alerts::init();
		Frontend::init();
		Cart::init();

		add_action( 'moc_prices_changed', array( __CLASS__, 'sync_wc_price' ), 30 );
		add_action( 'moc_config_saved', array( __CLASS__, 'sync_wc_price' ), 30 );
		add_action( 'before_delete_post', array( __CLASS__, 'on_delete_post' ) );

		if ( is_admin() ) {
			Admin\Product_Editor::init();
			Admin\Pages::init();
		}
	}

	/**
	 * Keep the WooCommerce price equal to the price of the default configuration, so shop lists,
	 * feeds and search show the right "from" price.
	 */
	public static function sync_wc_price( $product_id ) {
		if ( 'yes' !== get_option( 'moc_sync_wc_price', 'yes' ) ) {
			return;
		}
		$c = Config::get( $product_id );
		if ( ! $c || empty( $c['enabled'] ) ) {
			return;
		}
		$price = Pricing::default_price( $c, Price_Store::get( $product_id ) );
		$p     = wc_get_product( $product_id );
		if ( null === $price || ! $p || (float) $p->get_regular_price() === (float) $price ) {
			return;
		}
		$p->set_regular_price( wc_format_decimal( $price ) );
		$p->save();
	}

	public static function on_delete_post( $post_id ) {
		if ( 'product' === get_post_type( $post_id ) ) {
			Price_Store::delete_product( $post_id );
		}
	}
}
