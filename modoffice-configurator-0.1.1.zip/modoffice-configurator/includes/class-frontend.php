<?php
/**
 * Product page: layered preview, option controls and live price for enabled products.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Frontend {

	public static function init() {
		add_action( 'wp', array( __CLASS__, 'setup' ) );
		add_action( 'wp_ajax_moc_missing_hit', array( __CLASS__, 'ajax_missing_hit' ) );
		add_action( 'wp_ajax_nopriv_moc_missing_hit', array( __CLASS__, 'ajax_missing_hit' ) );
	}

	/** On an enabled product page: swap the gallery for the layered preview and add the controls. */
	public static function setup() {
		if ( ! is_product() ) {
			return;
		}
		$pid = get_queried_object_id();
		if ( ! Config::is_enabled( $pid ) ) {
			return;
		}
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
		add_action( 'woocommerce_before_single_product_summary', array( __CLASS__, 'render_preview' ), 20 );
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'render_controls' ), 5 );
		add_filter( 'woocommerce_get_price_html', array( __CLASS__, 'price_html' ), 20, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'body_class', static fn( $c ) => array_merge( $c, array( 'moc-configurable' ) ) );
	}

	public static function assets() {
		$pid = get_queried_object_id();
		wp_enqueue_style( 'moc-front', MOC_URL . 'assets/front/configurator.css', array(), MOC_VERSION . '.' . filemtime( MOC_DIR . 'assets/front/configurator.css' ) );
		wp_enqueue_script( 'moc-front', MOC_URL . 'assets/front/configurator.js', array(), MOC_VERSION . '.' . filemtime( MOC_DIR . 'assets/front/configurator.js' ), true );
		wp_localize_script( 'moc-front', 'mocData', self::js_data( $pid ) );
	}

	/** Everything the browser needs, with labels already in the visitor's language. */
	public static function js_data( $product_id ) {
		$c    = Config::get( $product_id );
		$lang = Config::current_lang();
		$img  = static function ( $id, $size ) {
			return $id ? (string) wp_get_attachment_image_url( $id, $size ) : '';
		};
		$layers = static function ( array $ls ) use ( $img ) {
			$out = array();
			foreach ( $ls as $l ) {
				$out[] = array( 'view' => $l['view'], 'src' => $img( $l['image'], 'large' ), 'z' => $l['z'], 'x' => $l['x'], 'y' => $l['y'] );
			}
			return $out;
		};

		$data = array(
			'productId' => (int) $product_id,
			'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'moc_front' ),
			'currency'  => array(
				'symbol'    => html_entity_decode( get_woocommerce_currency_symbol() ),
				'decimals'  => wc_get_price_decimals(),
				'decSep'    => wc_get_price_decimal_separator(),
				'thouSep'   => wc_get_price_thousand_separator(),
				'format'    => get_woocommerce_price_format(),
			),
			'fallbackImage' => $img( get_post_thumbnail_id( $product_id ), 'large' ),
			'baseLayers'    => $layers( $c['base_layers'] ),
			'dims'          => array(),
			'groups'        => array(),
			'prices'        => Price_Store::get( $product_id ),
			'defaults'      => Config::default_selection( $c ),
			'i18n'          => array(
				'dimension'   => __( 'Dimensions', 'modoffice-configurator' ),
				'total'       => __( 'Total', 'modoffice-configurator' ),
				'noPrice'     => __( 'The price of this combination is being updated. Please choose another combination or contact us.', 'modoffice-configurator' ),
				'choose'      => __( 'Please choose', 'modoffice-configurator' ),
				'none'        => __( 'None', 'modoffice-configurator' ),
				'yes'         => __( 'Yes', 'modoffice-configurator' ),
				'perUnit'     => __( 'incl. VAT, per piece', 'modoffice-configurator' ),
			),
		);
		foreach ( $c['dims'] as $d ) {
			$data['dims'][] = array( 'id' => $d['id'], 'label' => Config::label( $d['label'], $lang ), 'layers' => $layers( $d['layers'] ) );
		}
		foreach ( $c['groups'] as $g ) {
			$tiers = array();
			foreach ( $g['tiers'] as $t ) {
				$tiers[] = array( 'id' => $t['id'], 'label' => Config::label( $t['label'], $lang ) );
			}
			$opts = array();
			foreach ( $g['options'] as $o ) {
				$opts[] = array(
					'id'     => $o['id'],
					'label'  => Config::label( $o['label'], $lang ),
					'tier'   => $o['tier'],
					'swatch' => $img( $o['swatch'], 'thumbnail' ),
					'layers' => $layers( $o['layers'] ),
				);
			}
			$data['groups'][] = array(
				'id'       => $g['id'],
				'label'    => Config::label( $g['label'], $lang ),
				'type'     => $g['type'],
				'required' => $g['required'],
				'driver'   => $g['driver'],
				'tiers'    => $tiers,
				'options'  => $opts,
			);
		}
		return $data;
	}

	public static function render_preview() {
		echo '<div class="moc-preview-wrap woocommerce-product-gallery"><div class="moc-preview" aria-live="polite"></div></div>';
	}

	public static function render_controls() {
		global $product;
		if ( ! $product || ! Config::is_enabled( $product->get_id() ) ) {
			return;
		}
		echo '<div id="moc-configurator" class="moc-configurator"><noscript>' . esc_html__( 'Please enable JavaScript to configure this product.', 'modoffice-configurator' ) . '</noscript></div>';
		echo '<input type="hidden" name="moc_selection" id="moc_selection" value="" />';
	}

	/** On the configurable product page the summary price becomes the live total of the configurator. */
	public static function price_html( $html, $product ) {
		if ( is_product() && $product->get_id() === get_queried_object_id() && did_action( 'woocommerce_before_single_product' ) ) {
			return '<span class="moc-live-price">' . $html . '</span>';
		}
		return $html;
	}

	/** Customer reached a combination without a price → alert the administrator (rate-limited). */
	public static function ajax_missing_hit() {
		check_ajax_referer( 'moc_front', 'nonce' );
		$pid = absint( $_POST['product_id'] ?? 0 );
		$c   = Config::get( $pid );
		$sel = $c ? Config::validate_selection( $c, json_decode( wp_unslash( $_POST['selection'] ?? '' ), true ) ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated against the config.
		if ( ! $c || ! $sel || is_wp_error( $sel ) ) {
			wp_send_json_error();
		}
		$r = Pricing::compute( $c, $sel, Price_Store::get( $pid ) );
		if ( $r['missing'] ) {
			Alerts::customer_hit( $pid, $r['missing'] );
		}
		wp_send_json_success();
	}
}
