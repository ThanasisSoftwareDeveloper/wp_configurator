<?php
/**
 * Reads and writes rows of the `moc_prices` table, with history snapshots for restore.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Price_Store {

	const KINDS = array( 'matrix', 'surcharge' );

	private static $cache = array();

	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'moc_prices';
	}

	/**
	 * All prices of a product: [ 'matrix' => [ dim => [ key => price ] ], 'surcharge' => [...] ].
	 */
	public static function get( $product_id ) {
		$product_id = Config::source_id( $product_id );
		if ( isset( self::$cache[ $product_id ] ) ) {
			return self::$cache[ $product_id ];
		}
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare( 'SELECT kind, dim_id, price_key, price FROM ' . self::table() . ' WHERE product_id = %d', $product_id ),
			ARRAY_A
		);
		$out  = array( 'matrix' => array(), 'surcharge' => array() );
		foreach ( (array) $rows as $r ) {
			if ( isset( $out[ $r['kind'] ] ) ) {
				$out[ $r['kind'] ][ $r['dim_id'] ][ $r['price_key'] ] = (float) $r['price'];
			}
		}
		return self::$cache[ $product_id ] = $out;
	}

	/**
	 * Replace every price of a product with $prices (same shape as get()). Empty values are skipped.
	 */
	public static function replace( $product_id, array $prices ) {
		global $wpdb;
		$product_id = Config::source_id( $product_id );
		$wpdb->delete( self::table(), array( 'product_id' => $product_id ), array( '%d' ) );
		$now = current_time( 'mysql', true );
		foreach ( self::KINDS as $kind ) {
			foreach ( (array) ( $prices[ $kind ] ?? array() ) as $dim => $keys ) {
				foreach ( (array) $keys as $key => $price ) {
					$p = self::parse_price( $price );
					if ( null === $p || ! Config::clean_id( $dim ) || ! self::valid_key( $key ) ) {
						continue;
					}
					$wpdb->insert(
						self::table(),
						array(
							'product_id' => $product_id,
							'kind'       => $kind,
							'dim_id'     => $dim,
							'price_key'  => $key,
							'price'      => $p,
							'updated_at' => $now,
						),
						array( '%d', '%s', '%s', '%s', '%f', '%s' )
					);
				}
			}
		}
		unset( self::$cache[ $product_id ] );
		do_action( 'moc_prices_changed', $product_id );
	}

	/** Set (or with null: remove) a single price. */
	public static function set( $product_id, $kind, $dim, $key, $price ) {
		global $wpdb;
		$product_id = Config::source_id( $product_id );
		if ( ! in_array( $kind, self::KINDS, true ) || ! Config::clean_id( $dim ) || ! self::valid_key( $key ) ) {
			return false;
		}
		$wpdb->delete( self::table(), array( 'product_id' => $product_id, 'kind' => $kind, 'dim_id' => $dim, 'price_key' => $key ) );
		$p = self::parse_price( $price );
		if ( null !== $p ) {
			$wpdb->insert(
				self::table(),
				array(
					'product_id' => $product_id,
					'kind'       => $kind,
					'dim_id'     => $dim,
					'price_key'  => $key,
					'price'      => $p,
					'updated_at' => current_time( 'mysql', true ),
				)
			);
		}
		unset( self::$cache[ $product_id ] );
		return true;
	}

	public static function delete_product( $product_id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'product_id' => (int) $product_id ), array( '%d' ) );
		unset( self::$cache[ (int) $product_id ] );
	}

	/** Accepts 364, "364", "364,50", "1.234,50", "1,234.50". Returns float or null for empty/invalid. */
	public static function parse_price( $v ) {
		if ( is_int( $v ) || is_float( $v ) ) {
			return round( (float) $v, 2 );
		}
		$v = trim( str_replace( array( '€', ' ', "\xc2\xa0" ), '', (string) $v ) );
		if ( '' === $v ) {
			return null;
		}
		if ( preg_match( '/^-?\d{1,3}(\.\d{3})+(,\d+)?$/', $v ) ) {
			$v = str_replace( array( '.', ',' ), array( '', '.' ), $v );
		} elseif ( preg_match( '/^-?\d{1,3}(,\d{3})+(\.\d+)?$/', $v ) ) {
			$v = str_replace( ',', '', $v );
		} else {
			$v = str_replace( ',', '.', $v );
		}
		return is_numeric( $v ) ? round( (float) $v, 2 ) : null;
	}

	public static function valid_key( $key ) {
		return '' === $key || (bool) preg_match( '/^[a-z0-9_-]{1,32}:[a-z0-9_-]{1,32}(\|[a-z0-9_-]{1,32}:[a-z0-9_-]{1,32})*$/i', (string) $key );
	}

	public static function flush_cache() {
		self::$cache = array();
	}

	/* ---------- History ---------- */

	/** Save the current prices of the given products before a bulk change. Returns history id. */
	public static function snapshot( array $product_ids, $note ) {
		global $wpdb;
		$data = array();
		foreach ( array_unique( array_map( 'intval', $product_ids ) ) as $pid ) {
			$data[ $pid ] = self::get( $pid );
		}
		$wpdb->insert(
			$wpdb->prefix . 'moc_price_history',
			array(
				'created_at' => current_time( 'mysql', true ),
				'user_id'    => get_current_user_id(),
				'note'       => mb_substr( (string) $note, 0, 250 ),
				'snapshot'   => wp_json_encode( $data ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	public static function history( $limit = 30 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT id, created_at, user_id, note, LENGTH(snapshot) AS size FROM {$wpdb->prefix}moc_price_history ORDER BY id DESC LIMIT %d", $limit ),
			ARRAY_A
		);
	}

	/** Restore every product contained in a snapshot (a new snapshot of the current state is taken first). */
	public static function restore( $history_id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}moc_price_history WHERE id = %d", $history_id ), ARRAY_A );
		if ( ! $row ) {
			return new \WP_Error( 'moc_no_history', __( 'Snapshot not found.', 'modoffice-configurator' ) );
		}
		$data = json_decode( $row['snapshot'], true );
		if ( ! is_array( $data ) ) {
			return new \WP_Error( 'moc_bad_history', __( 'Snapshot is damaged.', 'modoffice-configurator' ) );
		}
		/* translators: %d: snapshot number. */
		self::snapshot( array_keys( $data ), sprintf( __( 'Before restoring snapshot #%d', 'modoffice-configurator' ), $history_id ) );
		foreach ( $data as $pid => $prices ) {
			self::replace( (int) $pid, (array) $prices );
		}
		return count( $data );
	}
}
