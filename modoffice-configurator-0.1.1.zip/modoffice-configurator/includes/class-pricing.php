<?php
/**
 * Price engine.
 *
 * Total = matrix price (dimension × tiers of the driver groups)
 *       + Σ surcharge (dimension × tier) of each selected option in the other groups.
 *
 * An optional driver group with nothing selected uses the tier id "none" in the key.
 * Every amount is the price incl. VAT, per unit, exactly as written in the price list.
 *
 * @package ModofficeConfigurator
 */

namespace MOC;

defined( 'ABSPATH' ) || exit;

class Pricing {

	const NONE = 'none';

	/** Matrix key for a selection, e.g. "g1:t2|g2:t1" ('' when the product has no driver groups). */
	public static function matrix_key( array $c, array $sel ) {
		$parts = array();
		foreach ( Config::driver_groups( $c ) as $g ) {
			$oid  = $sel['options'][ $g['id'] ] ?? null;
			$opt  = $oid ? Config::find_option( $g, $oid ) : null;
			$parts[] = $g['id'] . ':' . ( $opt ? $opt['tier'] : self::NONE );
		}
		return implode( '|', $parts );
	}

	/**
	 * Price a selection.
	 *
	 * @return array {
	 *   total: float|null (null when any needed price is missing),
	 *   lines: list of [label, amount|null],
	 *   missing: list of [kind, dim, key]
	 * }
	 */
	public static function compute( array $c, array $sel, array $prices ) {
		$dim     = $sel['dim'];
		$lines   = array();
		$missing = array();
		$total   = 0.0;

		$mkey = self::matrix_key( $c, $sel );
		$base = $prices['matrix'][ $dim ][ $mkey ] ?? null;
		$dimo = Config::find_dim( $c, $dim );
		$lines[] = array(
			'type'   => 'base',
			'label'  => $dimo ? Config::label( $dimo['label'] ) : $dim,
			'amount' => $base,
		);
		if ( null === $base ) {
			$missing[] = array( 'matrix', $dim, $mkey );
		} else {
			$total += $base;
		}

		foreach ( Config::surcharge_groups( $c ) as $g ) {
			$oid = $sel['options'][ $g['id'] ] ?? null;
			$opt = $oid ? Config::find_option( $g, $oid ) : null;
			if ( ! $opt ) {
				continue;
			}
			$key = $g['id'] . ':' . $opt['tier'];
			$amt = $prices['surcharge'][ $dim ][ $key ] ?? null;
			$lines[] = array(
				'type'   => 'surcharge',
				'label'  => Config::label( $g['label'] ) . ': ' . Config::label( $opt['label'] ),
				'amount' => $amt,
			);
			if ( null === $amt ) {
				$missing[] = array( 'surcharge', $dim, $key );
			} else {
				$total += $amt;
			}
		}

		return array(
			'total'   => $missing ? null : round( $total, 2 ),
			'lines'   => $lines,
			'missing' => $missing,
		);
	}

	/**
	 * Every price the product needs, as [kind, dim, key] tuples.
	 * Matrix: every dimension × every combination of used tiers of the driver groups
	 *         (plus "none" for optional driver groups).
	 * Surcharge: every dimension × every used tier of every other group.
	 */
	public static function required( array $c ) {
		$req     = array();
		$drivers = Config::driver_groups( $c );
		$combos  = array( array() );
		foreach ( $drivers as $g ) {
			$tiers = Config::used_tiers( $g );
			if ( ! $g['required'] ) {
				$tiers[] = self::NONE;
			}
			$next = array();
			foreach ( $combos as $combo ) {
				foreach ( $tiers as $t ) {
					$next[] = array_merge( $combo, array( $g['id'] . ':' . $t ) );
				}
			}
			$combos = $next;
		}
		foreach ( $c['dims'] as $d ) {
			foreach ( $combos as $combo ) {
				$req[] = array( 'matrix', $d['id'], implode( '|', $combo ) );
			}
			foreach ( Config::surcharge_groups( $c ) as $g ) {
				foreach ( Config::used_tiers( $g ) as $t ) {
					$req[] = array( 'surcharge', $d['id'], $g['id'] . ':' . $t );
				}
			}
		}
		return $req;
	}

	/** Required prices that are not set. */
	public static function missing( array $c, array $prices ) {
		$out = array();
		foreach ( self::required( $c ) as $r ) {
			if ( ! isset( $prices[ $r[0] ][ $r[1] ][ $r[2] ] ) ) {
				$out[] = $r;
			}
		}
		return $out;
	}

	/** Human-readable label of a price key, e.g. "Χρώμα σκελετού: Premium 1 · Επιφάνεια: Basic". */
	public static function key_label( array $c, $key, $lang = 'el' ) {
		if ( '' === $key ) {
			return __( 'Base price', 'modoffice-configurator' );
		}
		$parts = array();
		foreach ( explode( '|', $key ) as $pair ) {
			list( $gid, $tid ) = array_pad( explode( ':', $pair, 2 ), 2, '' );
			$g = Config::find_group( $c, $gid );
			if ( ! $g ) {
				$parts[] = $pair;
				continue;
			}
			if ( self::NONE === $tid ) {
				$tl = __( 'none', 'modoffice-configurator' );
			} else {
				$t  = Config::find_tier( $g, $tid );
				$tl = $t ? Config::label( $t['label'], $lang ) : $tid;
			}
			$parts[] = Config::label( $g['label'], $lang ) . ': ' . $tl;
		}
		return implode( ' · ', $parts );
	}

	public static function dim_label( array $c, $dim, $lang = 'el' ) {
		$d = Config::find_dim( $c, $dim );
		return $d ? Config::label( $d['label'], $lang ) : $dim;
	}

	/** Price of the default selection (used to sync the WooCommerce product price). */
	public static function default_price( array $c, array $prices ) {
		$r = self::compute( $c, Config::default_selection( $c ), $prices );
		return $r['total'];
	}
}
