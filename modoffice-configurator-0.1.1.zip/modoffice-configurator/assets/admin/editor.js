/* Modoffice Configurator — product editor (admin). Vanilla JS; jQuery only for WP media. */
(function () {
	'use strict';

	var root = document.getElementById('moc-editor');
	if (!root) { return; }

	var T = window.mocI18n || {};
	var LANGS = ['el', 'en', 'de'];
	var NONE = 'none';

	var state = {
		config: JSON.parse(root.getAttribute('data-config') || '{}'),
		prices: JSON.parse(root.getAttribute('data-prices') || '{}'),
		images: JSON.parse(root.getAttribute('data-images') || '{}')
	};
	if (Array.isArray(state.prices) || !state.prices) { state.prices = {}; }
	state.prices.matrix = obj(state.prices.matrix);
	state.prices.surcharge = obj(state.prices.surcharge);
	if (Array.isArray(state.images)) { state.images = {}; }

	function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
	function uid(p) { return p + Math.random().toString(36).slice(2, 8); }
	function lbl(l) { return (l && (l.el || l.en || l.de)) || ''; }
	function emptyLabel(text) { return { el: text || '', en: '', de: '' }; }

	/* ---------- DOM helpers ---------- */
	function h(tag, attrs, kids) {
		var el = document.createElement(tag);
		Object.keys(attrs || {}).forEach(function (k) {
			var v = attrs[k];
			if (k === 'class') { el.className = v; }
			else if (k === 'text') { el.textContent = v; }
			else if (k.indexOf('on') === 0) { el.addEventListener(k.slice(2), v); }
			else if (v === true) { el.setAttribute(k, ''); }
			else if (v !== false && v != null) { el.setAttribute(k, v); }
		});
		(kids || []).forEach(function (c) { if (c) { el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); } });
		return el;
	}
	function btn(text, onclick, cls) {
		return h('button', { type: 'button', class: 'button ' + (cls || ''), onclick: function (e) { e.preventDefault(); onclick(e); } }, [text]);
	}
	function labelInputs(label, onchange) {
		return h('span', { class: 'moc-labels' }, LANGS.map(function (l) {
			return h('input', {
				type: 'text', value: label[l] || '', placeholder: l.toUpperCase(), class: 'moc-lang moc-lang-' + l,
				oninput: function (e) { label[l] = e.target.value; if (onchange) { onchange(); } }
			});
		}));
	}
	function move(arr, i, d) {
		var j = i + d;
		if (j < 0 || j >= arr.length) { return; }
		var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
		render();
	}
	function removeAt(arr, i) {
		if (window.confirm(T.confirmRemove)) { arr.splice(i, 1); render(); }
	}
	function imagePicker(getId, setId) {
		var wrap = h('span', { class: 'moc-img' });
		function draw() {
			wrap.innerHTML = '';
			var id = getId();
			if (id && state.images[id]) { wrap.appendChild(h('img', { src: state.images[id], alt: '' })); }
			else if (id) { wrap.appendChild(h('span', { class: 'moc-img-id', text: '#' + id })); }
			wrap.appendChild(btn(id ? '✎' : T.choose, function () {
				var frame = wp.media({ title: T.chooseImage, button: { text: T.useImage }, multiple: false, library: { type: 'image' } });
				frame.on('select', function () {
					var a = frame.state().get('selection').first().toJSON();
					state.images[a.id] = (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url);
					setId(a.id); draw();
				});
				frame.open();
			}, 'button-small'));
			if (id) { wrap.appendChild(btn('×', function () { setId(0); draw(); }, 'button-small')); }
		}
		draw();
		return wrap;
	}
	function layerOf(item) {
		item.layers = item.layers || [];
		if (!item.layers.length) { item.layers.push({ view: 'front', image: 0, z: 0, x: 0, y: 0 }); }
		return item.layers[0];
	}

	/* ---------- Pricing helpers (mirror of PHP Pricing::required) ---------- */
	function drivers() { return state.config.groups.filter(function (g) { return g.type === 'single' && g.driver; }); }
	function others() { return state.config.groups.filter(function (g) { return !(g.type === 'single' && g.driver); }); }
	function usedTiers(g) {
		return g.tiers.filter(function (t) { return g.options.some(function (o) { return o.tier === t.id; }); });
	}
	function tierName(g, tid) {
		if (tid === NONE) { return T.none; }
		var t = g.tiers.filter(function (x) { return x.id === tid; })[0];
		return t ? lbl(t.label) : tid;
	}
	function matrixRows() {
		var rows = [{ key: [], label: [] }];
		drivers().forEach(function (g) {
			var tiers = usedTiers(g).map(function (t) { return t.id; });
			if (!g.required) { tiers.push(NONE); }
			var next = [];
			rows.forEach(function (r) {
				tiers.forEach(function (tid) {
					next.push({ key: r.key.concat(g.id + ':' + tid), label: r.label.concat(lbl(g.label) + ': ' + tierName(g, tid)) });
				});
			});
			rows = next;
		});
		return rows.map(function (r) { return { key: r.key.join('|'), label: r.label.join(' · ') || T.base }; });
	}
	function getPrice(kind, dim, key) {
		var d = state.prices[kind][dim];
		return d && d[key] !== undefined && d[key] !== null && d[key] !== '' ? d[key] : '';
	}
	function setPrice(kind, dim, key, v) {
		state.prices[kind][dim] = obj(state.prices[kind][dim]);
		if (v === '') { delete state.prices[kind][dim][key]; } else { state.prices[kind][dim][key] = v; }
	}

	/* ---------- Sections ---------- */
	function sectionEnabled() {
		var c = state.config;
		return h('div', { class: 'moc-box moc-enable' }, [
			h('label', {}, [
				h('input', { type: 'checkbox', checked: !!c.enabled, onchange: function (e) { c.enabled = e.target.checked; } }),
				' ', h('strong', { text: T.enabled })
			]),
			h('p', { class: 'description', text: T.enabledHelp })
		]);
	}

	function sectionBase() {
		var c = state.config;
		c.base_layers = c.base_layers || [];
		var l = c.base_layers[0] || null;
		return h('div', { class: 'moc-box' }, [
			h('h4', { text: T.baseLayers }),
			imagePicker(function () { return l ? l.image : 0; }, function (id) {
				if (!id) { c.base_layers = []; l = null; return; }
				if (!l) { l = { view: 'front', image: 0, z: 0, x: 0, y: 0 }; c.base_layers = [l]; }
				l.image = id;
			})
		]);
	}

	function sectionDims() {
		var c = state.config;
		var list = h('table', { class: 'widefat moc-table' }, [
			h('tbody', {}, c.dims.map(function (d, i) {
				var ly = layerOf(d);
				return h('tr', {}, [
					h('td', { class: 'moc-move' }, [btn('↑', function () { move(c.dims, i, -1); }, 'button-small'), btn('↓', function () { move(c.dims, i, 1); }, 'button-small')]),
					h('td', {}, [labelInputs(d.label, renderPrices)]),
					h('td', {}, [h('small', { text: T.layer + ' ' }), imagePicker(function () { return ly.image; }, function (id) { ly.image = id; })]),
					h('td', {}, [btn(T.remove, function () { removeAt(c.dims, i); }, 'button-link-delete')])
				]);
			}))
		]);
		return h('div', { class: 'moc-box' }, [
			h('h4', { text: T.dims }),
			list,
			btn('+ ' + T.addDim, function () { c.dims.push({ id: uid('d'), label: emptyLabel(T.newDim), layers: [] }); render(); })
		]);
	}

	function groupBox(g, gi) {
		var c = state.config;
		var head = h('div', { class: 'moc-group-head' }, [
			btn('↑', function () { move(c.groups, gi, -1); }, 'button-small'),
			btn('↓', function () { move(c.groups, gi, 1); }, 'button-small'),
			labelInputs(g.label, renderPrices),
			h('select', { onchange: function (e) { g.type = e.target.value; if (g.type === 'toggle') { g.driver = false; g.required = false; ensureToggle(g); } render(); } }, [
				h('option', { value: 'single', selected: g.type === 'single', text: T.single }),
				h('option', { value: 'toggle', selected: g.type === 'toggle', text: T.toggle })
			]),
			g.type === 'single' ? h('label', {}, [h('input', { type: 'checkbox', checked: !!g.required, onchange: function (e) { g.required = e.target.checked; renderPrices(); } }), ' ' + T.required]) : null,
			g.type === 'single' ? h('label', { title: T.driverHelp }, [h('input', { type: 'checkbox', checked: !!g.driver, onchange: function (e) { g.driver = e.target.checked; renderPrices(); } }), ' ' + T.driver]) : null,
			btn(T.remove, function () { removeAt(c.groups, gi); }, 'button-link-delete')
		]);

		var tiers = h('div', { class: 'moc-tiers' }, [h('strong', { text: T.tiers + ': ' })].concat(
			g.tiers.map(function (t, ti) {
				return h('span', { class: 'moc-tier' }, [
					labelInputs(t.label, function () { renderOptionsTierSelects(); renderPrices(); }),
					btn('×', function () {
						if (g.options.some(function (o) { return o.tier === t.id; })) { window.alert(T.tier + ': ' + lbl(t.label) + ' — ' + T.options); return; }
						removeAt(g.tiers, ti);
					}, 'button-small')
				]);
			})
		).concat([btn('+ ' + T.addTier, function () { g.tiers.push({ id: uid('t'), label: emptyLabel(T.newTier) }); render(); }, 'button-small')]));

		var rows = g.options.map(function (o, oi) {
			var ly = layerOf(o);
			var sel = h('select', { class: 'moc-tier-select', onchange: function (e) { o.tier = e.target.value; renderPrices(); } },
				g.tiers.map(function (t) { return h('option', { value: t.id, selected: o.tier === t.id, text: lbl(t.label) }); }));
			sel._group = g;
			return h('tr', {}, [
				h('td', { class: 'moc-move' }, [btn('↑', function () { move(g.options, oi, -1); }, 'button-small'), btn('↓', function () { move(g.options, oi, 1); }, 'button-small')]),
				h('td', {}, [labelInputs(o.label)]),
				h('td', {}, [sel]),
				g.type === 'single' ? h('td', {}, [h('label', {}, [h('input', { type: 'radio', name: 'moc-def-' + g.id, checked: !!o.default, onchange: function () { g.options.forEach(function (x) { x.default = x === o; }); } }), ' ' + T.default])]) : h('td'),
				h('td', {}, [h('small', { text: T.swatch + ' ' }), imagePicker(function () { return o.swatch; }, function (id) { o.swatch = id; })]),
				h('td', {}, [h('small', { text: T.layer + ' ' }), imagePicker(function () { return ly.image; }, function (id) { ly.image = id; }),
					h('input', { type: 'number', class: 'small-text', value: ly.z || 0, title: T.layerZ, oninput: function (e) { ly.z = parseInt(e.target.value, 10) || 0; } })]),
				h('td', {}, [btn(T.remove, function () { removeAt(g.options, oi); }, 'button-link-delete')])
			]);
		});

		return h('div', { class: 'moc-box moc-group' }, [
			head,
			tiers,
			h('table', { class: 'widefat moc-table' }, [h('tbody', {}, rows)]),
			g.type === 'single' || !g.options.length
				? btn('+ ' + T.addOption, function () {
					if (!g.tiers.length) { g.tiers.push({ id: uid('t'), label: emptyLabel('Basic') }); }
					g.options.push({ id: uid('o'), label: emptyLabel(T.newOption), tier: g.tiers[0].id, swatch: 0, default: false, layers: [] });
					render();
				})
				: null
		]);
	}

	function ensureToggle(g) {
		if (!g.tiers.length) { g.tiers.push({ id: uid('t'), label: emptyLabel(lbl(g.label) || 'Extra') }); }
		if (!g.options.length) { g.options.push({ id: uid('o'), label: emptyLabel('Ναι'), tier: g.tiers[0].id, swatch: 0, default: false, layers: [] }); }
	}

	function renderOptionsTierSelects() {
		root.querySelectorAll('select.moc-tier-select').forEach(function (s) {
			var g = s._group;
			Array.prototype.forEach.call(s.options, function (op, i) { if (g.tiers[i]) { op.textContent = lbl(g.tiers[i].label); } });
		});
	}

	function sectionGroups() {
		var c = state.config;
		return h('div', { class: 'moc-section' }, [
			h('h3', { text: T.groups }),
			h('div', {}, c.groups.map(groupBox)),
			btn('+ ' + T.addGroup, function () {
				var t = { id: uid('t'), label: emptyLabel('Basic') };
				c.groups.push({ id: uid('g'), label: emptyLabel(T.newGroup), type: 'single', required: true, driver: c.groups.length === 0, tiers: [t], options: [] });
				render();
			}, 'button-primary')
		]);
	}

	/* ---------- Price tables ---------- */
	var pricesHost = h('div', { class: 'moc-section moc-prices' });

	function priceTable(title, kind, rows) {
		var dims = state.config.dims;
		var missing = 0;
		var thead = h('thead', {}, [h('tr', {}, [h('th', { text: title })].concat(dims.map(function (d) { return h('th', { text: lbl(d.label) }); })).concat([h('th')]))]);
		var tbody = h('tbody', {}, rows.map(function (r) {
			var cells = dims.map(function (d) {
				var v = getPrice(kind, d.id, r.key);
				if (v === '') { missing++; }
				var inp = h('input', {
					type: 'text', inputmode: 'decimal', class: 'moc-price' + (v === '' ? ' moc-missing' : ''), value: v,
					oninput: function (e) {
						var val = e.target.value.trim();
						setPrice(kind, d.id, r.key, val);
						e.target.classList.toggle('moc-missing', val === '');
						updateSummary();
					}
				});
				return h('td', {}, [inp]);
			});
			return h('tr', {}, [h('th', { text: r.label })].concat(cells).concat([h('td', {}, [btn(T.fillRow, function () {
				var v = window.prompt(T.fillRowPrompt, '');
				if (v === null) { return; }
				dims.forEach(function (d) { setPrice(kind, d.id, r.key, v.trim()); });
				renderPrices();
			}, 'button-small')])]));
		}));
		return { el: h('table', { class: 'widefat moc-price-table' }, [thead, tbody]), missing: missing };
	}

	var summary = h('p', { class: 'moc-summary' });
	function updateSummary() {
		var n = pricesHost.querySelectorAll('input.moc-missing').length;
		summary.className = 'moc-summary ' + (n ? 'moc-bad' : 'moc-good');
		summary.textContent = n ? (n + ' ' + T.missing) : T.allPriced;
	}

	function renderPrices() {
		pricesHost.innerHTML = '';
		pricesHost.appendChild(h('h3', { text: T.prices }));
		if (!state.config.dims.length) { pricesHost.appendChild(h('p', { text: T.noDims })); return; }
		pricesHost.appendChild(summary);
		var m = priceTable(T.fullPrice, 'matrix', matrixRows());
		pricesHost.appendChild(m.el);
		others().forEach(function (g) {
			var rows = usedTiers(g).map(function (t) { return { key: g.id + ':' + t.id, label: lbl(t.label) }; });
			if (!rows.length) { return; }
			pricesHost.appendChild(h('h4', { text: lbl(g.label) + ' — ' + T.surcharge }));
			pricesHost.appendChild(priceTable(lbl(g.label), 'surcharge', rows).el);
		});
		updateSummary();
	}

	/* ---------- Render & save ---------- */
	function render() {
		root.innerHTML = '';
		root.appendChild(sectionEnabled());
		root.appendChild(sectionBase());
		root.appendChild(sectionDims());
		root.appendChild(sectionGroups());
		root.appendChild(pricesHost);
		renderPrices();
	}

	function serialize() {
		document.getElementById('moc_config_json').value = JSON.stringify(state.config);
		document.getElementById('moc_prices_json').value = JSON.stringify(state.prices);
	}

	var form = document.getElementById('post');
	if (form) { form.addEventListener('submit', serialize); }

	state.config.groups = state.config.groups || [];
	state.config.dims = state.config.dims || [];
	render();
	serialize();
}());
