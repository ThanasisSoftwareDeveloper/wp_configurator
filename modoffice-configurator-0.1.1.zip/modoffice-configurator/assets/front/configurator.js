/* Modoffice Configurator — product page. No dependencies. */
(function () {
	'use strict';

	var D = window.mocData;
	var host = document.getElementById('moc-configurator');
	if (!D || !host) { return; }

	var NONE = 'none';
	var input = document.getElementById('moc_selection');
	var form = host.closest('form.cart');
	var button = form ? form.querySelector('button[type=submit], .single_add_to_cart_button') : null;
	var preview = document.querySelector('.moc-preview');
	var reported = {};

	var sel = { dim: D.defaults.dim, options: {} };
	Object.keys(D.defaults.options || {}).forEach(function (k) { sel.options[k] = D.defaults.options[k]; });

	/* ---------- helpers ---------- */
	function h(tag, attrs, kids) {
		var el = document.createElement(tag);
		Object.keys(attrs || {}).forEach(function (k) {
			var v = attrs[k];
			if (k === 'class') { el.className = v; }
			else if (k === 'text') { el.textContent = v; }
			else if (k.indexOf('on') === 0) { el.addEventListener(k.slice(2), v); }
			else if (v === true) { el.setAttribute(k, ''); }
			else if (v !== false && v != null) { el.setAttribute(k, v); }
		});
		(kids || []).forEach(function (c) { if (c) { el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); } });
		return el;
	}
	function money(v) {
		var c = D.currency;
		var n = Math.abs(v).toFixed(c.decimals).split('.');
		n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, c.thouSep);
		var num = n.join(c.decSep);
		var out = c.format.replace('%1$s', c.symbol).replace('%2$s', num).replace(/&nbsp;/g, ' ');
		return (v < 0 ? '-' : '') + out;
	}
	function groupById(id) { return D.groups.filter(function (g) { return g.id === id; })[0]; }
	function optionOf(g, oid) { return g.options.filter(function (o) { return o.id === oid; })[0]; }

	/* ---------- pricing (mirror of PHP Pricing::compute) ---------- */
	function compute() {
		var keyParts = [];
		D.groups.forEach(function (g) {
			if (g.type === 'single' && g.driver) {
				var o = sel.options[g.id] ? optionOf(g, sel.options[g.id]) : null;
				keyParts.push(g.id + ':' + (o ? o.tier : NONE));
			}
		});
		var mk = keyParts.join('|');
		var m = (D.prices.matrix || {})[sel.dim] || {};
		var s = (D.prices.surcharge || {})[sel.dim] || {};
		var missing = [];
		var total = 0;
		if (m[mk] === undefined) { missing.push(['matrix', sel.dim, mk]); } else { total += +m[mk]; }
		D.groups.forEach(function (g) {
			if (g.type === 'single' && g.driver) { return; }
			var oid = sel.options[g.id];
			var o = oid ? optionOf(g, oid) : null;
			if (!o) { return; }
			var k = g.id + ':' + o.tier;
			if (s[k] === undefined) { missing.push(['surcharge', sel.dim, k]); } else { total += +s[k]; }
		});
		return { total: missing.length ? null : Math.round(total * 100) / 100, missing: missing };
	}

	/* ---------- preview ---------- */
	function drawPreview() {
		if (!preview) { return; }
		var layers = [].concat(D.baseLayers || []);
		var dim = D.dims.filter(function (d) { return d.id === sel.dim; })[0];
		if (dim) { layers = layers.concat(dim.layers || []); }
		D.groups.forEach(function (g) {
			var o = sel.options[g.id] ? optionOf(g, sel.options[g.id]) : null;
			if (o) { layers = layers.concat(o.layers || []); }
		});
		layers = layers.filter(function (l) { return l.src && (l.view || 'front') === 'front'; });
		layers.sort(function (a, b) { return (a.z || 0) - (b.z || 0); });
		preview.innerHTML = '';
		if (!layers.length && D.fallbackImage) { layers = [{ src: D.fallbackImage, z: 0 }]; }
		layers.forEach(function (l, i) {
			var img = h('img', { src: l.src, alt: '', class: 'moc-layer' + (i === 0 ? ' moc-layer-base' : ''), loading: 'eager', decoding: 'async' });
			if (l.x || l.y) { img.style.transform = 'translate(' + (l.x || 0) + '%,' + (l.y || 0) + '%)'; }
			preview.appendChild(img);
		});
	}

	/* ---------- controls ---------- */
	function choiceButton(label, swatch, active, onclick, extraClass) {
		return h('button', {
			type: 'button', class: 'moc-choice' + (swatch ? ' moc-has-swatch' : '') + (active ? ' is-active' : '') + (extraClass ? ' ' + extraClass : ''),
			'aria-pressed': active ? 'true' : 'false', title: label, onclick: function (e) { e.preventDefault(); onclick(); }
		}, [swatch ? h('img', { src: swatch, alt: '' }) : null, h('span', { class: 'moc-choice-label', text: label })]);
	}

	function renderControls() {
		host.innerHTML = '';

		if (D.dims.length > 1) {
			host.appendChild(h('div', { class: 'moc-group moc-dims' }, [
				h('div', { class: 'moc-group-title', text: D.i18n.dimension }),
				h('div', { class: 'moc-choices' }, D.dims.map(function (d) {
					return choiceButton(d.label, '', sel.dim === d.id, function () { sel.dim = d.id; update(); });
				}))
			]));
		}

		D.groups.forEach(function (g) {
			if (!g.options.length) { return; }
			var chosen = sel.options[g.id] ? optionOf(g, sel.options[g.id]) : null;
			var title = h('div', { class: 'moc-group-title' }, [g.label, chosen ? h('span', { class: 'moc-chosen', text: ': ' + chosen.label }) : null]);

			if (g.type === 'toggle') {
				var o = g.options[0];
				host.appendChild(h('div', { class: 'moc-group moc-toggle' }, [
					h('label', {}, [
						h('input', { type: 'checkbox', checked: !!sel.options[g.id], onchange: function (e) { sel.options[g.id] = e.target.checked ? o.id : null; update(); } }),
						' ' + g.label
					])
				]));
				return;
			}

			var blocks = g.tiers.map(function (t) {
				var opts = g.options.filter(function (o) { return o.tier === t.id; });
				if (!opts.length) { return null; }
				return h('div', { class: 'moc-tier' }, [
					g.tiers.length > 1 ? h('div', { class: 'moc-tier-title', text: t.label }) : null,
					h('div', { class: 'moc-choices' }, opts.map(function (o) {
						return choiceButton(o.label, o.swatch, sel.options[g.id] === o.id, function () { sel.options[g.id] = o.id; update(); });
					}))
				]);
			});
			if (!g.required) {
				blocks.push(h('div', { class: 'moc-choices' }, [choiceButton(D.i18n.none, '', !sel.options[g.id], function () { sel.options[g.id] = null; update(); }, 'moc-none')]));
			}
			host.appendChild(h('div', { class: 'moc-group' }, [title].concat(blocks)));
		});

		host.appendChild(h('div', { class: 'moc-total' }, [
			h('span', { class: 'moc-total-label', text: D.i18n.total + ': ' }),
			h('strong', { class: 'moc-total-value' }),
			h('small', { class: 'moc-total-note', text: ' ' + D.i18n.perUnit })
		]));
		host.appendChild(h('div', { class: 'moc-message', role: 'alert' }));
	}

	function update() {
		renderControls();
		drawPreview();
		var r = compute();
		var val = host.querySelector('.moc-total-value');
		var msg = host.querySelector('.moc-message');
		var live = document.querySelectorAll('.moc-live-price');
		input.value = JSON.stringify(sel);

		if (r.total === null) {
			val.textContent = '—';
			msg.textContent = D.i18n.noPrice;
			msg.style.display = '';
			if (button) { button.disabled = true; button.classList.add('disabled'); }
			reportMissing();
		} else {
			val.textContent = money(r.total);
			msg.textContent = '';
			msg.style.display = 'none';
			if (button) { button.disabled = false; button.classList.remove('disabled'); }
			Array.prototype.forEach.call(live, function (el) { el.textContent = money(r.total); });
		}
	}

	function reportMissing() {
		var key = JSON.stringify(sel);
		if (reported[key]) { return; }
		reported[key] = true;
		var body = new FormData();
		body.append('action', 'moc_missing_hit');
		body.append('nonce', D.nonce);
		body.append('product_id', D.productId);
		body.append('selection', key);
		if (window.fetch) { fetch(D.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' }).catch(function () {}); }
	}

	if (form) {
		form.addEventListener('submit', function (e) {
			input.value = JSON.stringify(sel);
			if (compute().total === null) { e.preventDefault(); }
		});
	}

	update();
}());
