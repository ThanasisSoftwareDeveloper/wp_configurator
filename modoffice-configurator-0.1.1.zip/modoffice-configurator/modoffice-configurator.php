<?php
/**
 * Plugin Name:       Modoffice Configurator
 * Description:       Product configurator with combination pricing (dimension × price tier), layered images and CSV price import. Replaces WP Configurator Pro.
 * Version:           0.1.1
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Modoffice
 * Text Domain:       modoffice-configurator
 * Domain Path:       /languages
 * WC requires at least: 8.0
 *
 * @package ModofficeConfigurator
 */

defined( 'ABSPATH' ) || exit;

define( 'MOC_VERSION', '0.1.1' );
define( 'MOC_DB_VERSION', '1' );
define( 'MOC_FILE', __FILE__ );
define( 'MOC_DIR', plugin_dir_path( __FILE__ ) );
define( 'MOC_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(
	static function ( $class ) {
		if ( 0 !== strpos( $class, 'MOC\\' ) ) {
			return;
		}
		$rel  = strtolower( str_replace( array( 'MOC\\', '_' ), array( '', '-' ), $class ) );
		$rel  = str_replace( '\\', '/', $rel );
		$base = basename( $rel );
		$dir  = dirname( $rel );
		$file = MOC_DIR . 'includes/' . ( '.' === $dir ? '' : $dir . '/' ) . 'class-' . $base . '.php';
		if ( is_readable( $file ) ) {
			require $file;
		}
	}
);

register_activation_hook( __FILE__, array( 'MOC\\Install', 'activate' ) );

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain( 'modoffice-configurator', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				static function () {
					echo '<div class="notice notice-error"><p>' . esc_html__( 'Modoffice Configurator requires WooCommerce.', 'modoffice-configurator' ) . '</p></div>';
				}
			);
			return;
		}
		MOC\Plugin::instance();
	}
);
